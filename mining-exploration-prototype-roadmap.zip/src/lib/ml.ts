// Lightweight ML implementations for the prototype (mirrors the scikit-learn
// pipeline described in the roadmap: RandomForestRegressor + LinearRegression).

function mulberry32(a: number) {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type TreeNode =
  | { leaf: true; value: number }
  | { leaf: false; feature: number; threshold: number; left: TreeNode; right: TreeNode };

function mean(xs: number[]) {
  return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0;
}
function variance(xs: number[]) {
  const m = mean(xs);
  return mean(xs.map((x) => (x - m) ** 2));
}

function buildTree(X: number[][], y: number[], depth: number, maxDepth: number, minLeaf: number, rnd: () => number, nFeat: number): TreeNode {
  if (depth >= maxDepth || y.length <= minLeaf * 2 || variance(y) < 1e-9) {
    return { leaf: true, value: mean(y) };
  }
  const nFeatures = X[0].length;
  const featIdx = Array.from({ length: nFeatures }, (_, i) => i)
    .sort(() => rnd() - 0.5)
    .slice(0, nFeat);
  let best: { f: number; t: number; score: number } | null = null;
  for (const f of featIdx) {
    const vals = Array.from(new Set(X.map((r) => r[f]))).sort((a, b) => a - b);
    for (let i = 1; i < vals.length; i++) {
      const t = (vals[i - 1] + vals[i]) / 2;
      const ly: number[] = [];
      const ry: number[] = [];
      for (let k = 0; k < X.length; k++) (X[k][f] <= t ? ly : ry).push(y[k]);
      if (ly.length < minLeaf || ry.length < minLeaf) continue;
      const score = (ly.length * variance(ly) + ry.length * variance(ry)) / y.length;
      if (!best || score < best.score) best = { f, t, score };
    }
  }
  if (!best) return { leaf: true, value: mean(y) };
  const lX: number[][] = [], ly: number[] = [], rX: number[][] = [], ry: number[] = [];
  for (let k = 0; k < X.length; k++) {
    if (X[k][best.f] <= best.t) { lX.push(X[k]); ly.push(y[k]); } else { rX.push(X[k]); ry.push(y[k]); }
  }
  return {
    leaf: false,
    feature: best.f,
    threshold: best.t,
    left: buildTree(lX, ly, depth + 1, maxDepth, minLeaf, rnd, nFeat),
    right: buildTree(rX, ry, depth + 1, maxDepth, minLeaf, rnd, nFeat),
  };
}

function predictTree(node: TreeNode, x: number[]): number {
  while (!node.leaf) node = x[node.feature] <= node.threshold ? node.left : node.right;
  return node.value;
}

export class RandomForestRegressor {
  private trees: TreeNode[] = [];
  private importances: number[] = [];
  constructor(private nEstimators = 40, private maxDepth = 5, private minLeaf = 2, private seed = 42) {}

  fit(X: number[][], y: number[]) {
    const rnd = mulberry32(this.seed);
    const nFeat = Math.max(1, Math.round(Math.sqrt(X[0].length)));
    this.trees = [];
    this.importances = new Array(X[0].length).fill(0);
    for (let i = 0; i < this.nEstimators; i++) {
      const bx: number[][] = [], by: number[] = [];
      for (let k = 0; k < X.length; k++) {
        const j = Math.floor(rnd() * X.length);
        bx.push(X[j]); by.push(y[j]);
      }
      const tree = buildTree(bx, by, 0, this.maxDepth, this.minLeaf, rnd, nFeat);
      this.trees.push(tree);
      this.accumulateImportance(tree, 1);
    }
    const total = this.importances.reduce((a, b) => a + b, 0) || 1;
    this.importances = this.importances.map((v) => v / total);
    return this;
  }

  private accumulateImportance(node: TreeNode, weight: number) {
    if (node.leaf) return;
    this.importances[node.feature] += weight;
    this.accumulateImportance(node.left, weight * 0.6);
    this.accumulateImportance(node.right, weight * 0.6);
  }

  predict(x: number[]) {
    return mean(this.trees.map((t) => predictTree(t, x)));
  }

  /** Prediction spread across trees (used as a confidence proxy) */
  predictWithSpread(x: number[]) {
    const preds = this.trees.map((t) => predictTree(t, x));
    return { mean: mean(preds), std: Math.sqrt(variance(preds)) };
  }

  featureImportances() {
    return this.importances;
  }

  score(X: number[][], y: number[]) {
    const yBar = mean(y);
    const ssTot = y.reduce((a, v) => a + (v - yBar) ** 2, 0) || 1;
    const ssRes = y.reduce((a, v, i) => a + (v - this.predict(X[i])) ** 2, 0);
    return 1 - ssRes / ssTot;
  }
}

export function linearRegression(xs: number[], ys: number[]) {
  const n = xs.length;
  const mx = mean(xs), my = mean(ys);
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (xs[i] - mx) * (ys[i] - my); den += (xs[i] - mx) ** 2; }
  const slope = den ? num / den : 0;
  const intercept = my - slope * mx;
  const residuals = ys.map((y, i) => y - (intercept + slope * xs[i]));
  const rmse = Math.sqrt(mean(residuals.map((r) => r * r)));
  return { slope, intercept, rmse, predict: (x: number) => intercept + slope * x };
}

export type RiskLevel = "Low" | "Medium" | "High" | "Critical";

export function classifyRisk(score: number): RiskLevel {
  if (score >= 75) return "Critical";
  if (score >= 50) return "High";
  if (score >= 25) return "Medium";
  return "Low";
}

export type RiskFactors = {
  shortfallPct: number; // % below target
  gradeDeclinePct: number; // % decline in Mn grade over period
  uptimePct: number; // avg equipment uptime
  reserveLifeYears: number;
  monsoonExposure: number; // 0-1 (production drop in monsoon vs rest)
  vegetationEncroachment: number; // NDVI change
};

export function computeRiskScore(f: RiskFactors) {
  // Weighted composite (0-100). Weights are prototype heuristics.
  const components = [
    { name: "Production shortfall", weight: 0.35, value: clamp(f.shortfallPct / 30) },
    { name: "Grade decline", weight: 0.2, value: clamp(f.gradeDeclinePct / 10) },
    { name: "Equipment downtime", weight: 0.15, value: clamp((90 - f.uptimePct) / 20) },
    { name: "Reserve depletion", weight: 0.15, value: clamp((15 - f.reserveLifeYears) / 15) },
    { name: "Monsoon exposure", weight: 0.1, value: clamp(f.monsoonExposure / 0.3) },
    { name: "Environmental / land change", weight: 0.05, value: clamp(f.vegetationEncroachment / 0.2) },
  ];
  const score = components.reduce((a, c) => a + c.weight * c.value * 100, 0);
  return {
    score: Math.round(score),
    level: classifyRisk(score),
    components: components.map((c) => ({ ...c, contribution: Math.round(c.weight * c.value * 100) })),
  };
}

function clamp(v: number) {
  return Math.max(0, Math.min(1, v));
}
