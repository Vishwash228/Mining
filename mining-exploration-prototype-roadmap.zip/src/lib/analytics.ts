import { db } from "@/db";
import { mines, zones, drillholes, production, satelliteFeatures, equipment, type Mine, type Zone, type Drillhole } from "@/db/schema";
import { eq, asc, and } from "drizzle-orm";
import { ensureSeeded } from "./seed";
import { RandomForestRegressor, linearRegression, computeRiskScore, type RiskLevel } from "./ml";

export const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export async function getMines() {
  await ensureSeeded();
  return db.select().from(mines).orderBy(asc(mines.code));
}

export async function getMine(id: number) {
  await ensureSeeded();
  const [m] = await db.select().from(mines).where(eq(mines.id, id));
  return m ?? null;
}

export async function getZones(mineId: number) {
  await ensureSeeded();
  return db.select().from(zones).where(eq(zones.mineId, mineId)).orderBy(asc(zones.code));
}

export async function getDrillholes(mineId: number) {
  await ensureSeeded();
  return db.select().from(drillholes).where(eq(drillholes.mineId, mineId)).orderBy(asc(drillholes.holeId));
}

export async function getProduction(mineId: number) {
  await ensureSeeded();
  return db
    .select()
    .from(production)
    .where(and(eq(production.mineId, mineId), eq(production.isForecast, false)))
    .orderBy(asc(production.year), asc(production.month));
}

export async function getSatellite(mineId: number) {
  await ensureSeeded();
  return db.select().from(satelliteFeatures).where(eq(satelliteFeatures.mineId, mineId)).orderBy(asc(satelliteFeatures.captureDate));
}

export async function getEquipment(mineId: number) {
  await ensureSeeded();
  return db.select().from(equipment).where(eq(equipment.mineId, mineId)).orderBy(asc(equipment.code));
}

/** Today's shift-level production view (derived from the latest monthly rate). */
export async function getTodaySnapshot(mineId: number) {
  const [hist, fleet, sat] = await Promise.all([getProduction(mineId), getEquipment(mineId), getSatellite(mineId)]);
  const lastMonth = hist[hist.length - 1];
  const targetT = Math.round((lastMonth.targetKt * 1000) / 26 / 10) * 10; // tonnes/day, 26 working days
  const rateFactor = lastMonth.producedKt / lastMonth.targetKt;
  const healthy = fleet.filter((e) => e.status === "Healthy").length;
  const uptimePenalty = 1 - (fleet.length - healthy) * 0.012;
  const rainfallMm = Math.round(30 + (sat[sat.length - 1]?.ndvi ?? 0.3) * 60);
  const rainPenalty = rainfallMm > 40 ? 0.96 : 1;
  const predictedT = Math.round((targetT * rateFactor * uptimePenalty * rainPenalty) / 10) * 10;
  // Hourly curve 06:00 → 14:00 (current time) then predicted to 22:00
  const hours = Array.from({ length: 17 }, (_, i) => 6 + i);
  const nowHour = 14;
  const points = hours.map((h) => {
    const frac = (h - 6) / 16;
    const target = Math.round(targetT * frac);
    const dip = h >= 10 && h <= 12 ? 0.9 : 1; // blasting delay
    const actual = h <= nowHour ? Math.round(predictedT * frac * dip * 0.97) : null;
    const predicted = h >= nowHour ? Math.round(predictedT * frac) : null;
    return { label: `${String(h).padStart(2, "0")}:00`, target, actual, predicted };
  });
  const currentT = points.find((p) => p.label === "14:00")?.actual ?? 0;
  return {
    targetT,
    currentT,
    predictedT,
    shortfallT: Math.max(0, targetT - predictedT),
    shortfallLevel: targetT - predictedT > targetT * 0.1 ? "HIGH" : targetT - predictedT > 0 ? "MEDIUM" : "LOW",
    points,
    fleet,
    healthy,
    fleetHealth: Math.round(fleet.reduce((a, e) => a + e.healthScore, 0) / fleet.length),
    rainfallMm,
    soilMoisture: rainfallMm > 40 ? "High" : "Moderate",
    envStatus: rainfallMm > 60 ? "HIGH" : rainfallMm > 35 ? "MODERATE" : "NORMAL",
    critical: fleet.filter((e) => e.status === "Critical"),
  };
}

// ---------- Reserve prediction (Random Forest) ----------

export const RESERVE_FEATURES = ["Depth (m)", "Thickness (m)", "Fe %", "SiO2 %", "NDVI", "Iron-oxide index", "Clay index"];

function drillholeFeatures(h: Drillhole, z: Zone | undefined) {
  return [h.depthM, h.thicknessM, h.fePct, h.sio2Pct, z?.ndvi ?? 0.3, z?.ironOxideIndex ?? 1.5, z?.clayIndex ?? 1.4];
}

let cachedModel: { model: RandomForestRegressor; r2: number; n: number } | null = null;

export async function getReserveModel() {
  await ensureSeeded();
  if (cachedModel) return cachedModel;
  const allHoles = await db.select().from(drillholes);
  const allZones = await db.select().from(zones);
  const zoneMap = new Map(allZones.map((z) => [z.id, z]));
  const X = allHoles.map((h) => drillholeFeatures(h, h.zoneId ? zoneMap.get(h.zoneId) : undefined));
  const y = allHoles.map((h) => h.mnPct);
  const model = new RandomForestRegressor(40, 5, 2, 7).fit(X, y);
  cachedModel = { model, r2: model.score(X, y), n: allHoles.length };
  return cachedModel;
}

export type ZonePrediction = {
  zone: Zone;
  predictedGradePct: number;
  gradeStd: number;
  predictedReserveMt: number;
  confidence: number;
  holes: Drillhole[];
};

export async function predictZones(mineId: number): Promise<ZonePrediction[]> {
  const [{ model }, zs, holes] = await Promise.all([getReserveModel(), getZones(mineId), getDrillholes(mineId)]);
  return zs.map((zone) => {
    const zHoles = holes.filter((h) => h.zoneId === zone.id);
    const preds = zHoles.map((h) => model.predictWithSpread(drillholeFeatures(h, zone)));
    const grade = preds.length ? preds.reduce((a, p) => a + p.mean, 0) / preds.length : zone.avgGradeMnPct;
    const std = preds.length ? preds.reduce((a, p) => a + p.std, 0) / preds.length : 3;
    const avgThickness = zHoles.length ? zHoles.reduce((a, h) => a + h.thicknessM, 0) / zHoles.length : 3;
    // Tonnage = area(m²) × thickness(m) × bulk density(3.4 t/m³) × probability, in MT
    const reserveMt = (zone.areaHa * 10000 * avgThickness * 3.4 * zone.probability) / 1e6;
    return {
      zone,
      predictedGradePct: +grade.toFixed(2),
      gradeStd: +std.toFixed(2),
      predictedReserveMt: +reserveMt.toFixed(2),
      confidence: Math.round(Math.max(40, Math.min(97, 100 - std * 6 - (4 - zHoles.length) * 5))),
      holes: zHoles,
    };
  });
}

// ---------- Production forecast ----------

export type ForecastPoint = {
  label: string;
  year: number;
  month: number;
  actual: number | null;
  forecast: number | null;
  lower: number | null;
  upper: number | null;
  target: number;
};

export async function forecastProduction(mineId: number, horizon = 12) {
  const hist = await getProduction(mineId);
  const last = hist.slice(-36);
  // Seasonal decomposition: monthly multiplier relative to overall mean
  const overall = last.reduce((a, r) => a + r.producedKt, 0) / last.length;
  const seasonal: number[] = new Array(12).fill(0).map((_, m) => {
    const rows = last.filter((r) => r.month === m + 1);
    return rows.length ? rows.reduce((a, r) => a + r.producedKt, 0) / rows.length / overall : 1;
  });
  const deseason = last.map((r, i) => ({ x: i, y: r.producedKt / seasonal[r.month - 1] }));
  const lr = linearRegression(deseason.map((d) => d.x), deseason.map((d) => d.y));
  const target = hist[hist.length - 1].targetKt;

  const points: ForecastPoint[] = hist.slice(-24).map((r) => ({
    label: `${MONTHS[r.month - 1]} ${String(r.year).slice(2)}`,
    year: r.year,
    month: r.month,
    actual: r.producedKt,
    forecast: null,
    lower: null,
    upper: null,
    target: r.targetKt,
  }));
  let y = hist[hist.length - 1].year;
  let m = hist[hist.length - 1].month;
  const forecastVals: number[] = [];
  for (let i = 1; i <= horizon; i++) {
    m++;
    if (m > 12) { m = 1; y++; }
    const base = lr.predict(last.length - 1 + i) * seasonal[m - 1];
    const band = lr.rmse * (1 + i * 0.08) * 1.64;
    forecastVals.push(base);
    points.push({
      label: `${MONTHS[m - 1]} ${String(y).slice(2)}`,
      year: y,
      month: m,
      actual: null,
      forecast: +base.toFixed(2),
      lower: +Math.max(0, base - band).toFixed(2),
      upper: +(base + band).toFixed(2),
      target,
    });
  }
  // Connect the last actual with the forecast line
  const lastActualIdx = points.findIndex((p) => p.forecast !== null) - 1;
  if (lastActualIdx >= 0) {
    points[lastActualIdx].forecast = points[lastActualIdx].actual;
    points[lastActualIdx].lower = points[lastActualIdx].actual;
    points[lastActualIdx].upper = points[lastActualIdx].actual;
  }

  const forecastTotalKt = forecastVals.reduce((a, b) => a + b, 0);
  const targetTotalKt = target * horizon;
  const lastYearActualKt = hist.slice(-12).reduce((a, r) => a + r.producedKt, 0);
  return {
    points,
    forecastTotalMt: +(forecastTotalKt / 1000).toFixed(3),
    targetTotalMt: +(targetTotalKt / 1000).toFixed(3),
    lastYearActualMt: +(lastYearActualKt / 1000).toFixed(3),
    shortfallPct: +(((targetTotalKt - forecastTotalKt) / targetTotalKt) * 100).toFixed(1),
    trendKtPerMonth: +lr.slope.toFixed(3),
    rmse: +lr.rmse.toFixed(2),
    model: "Seasonal Linear Regression (36-month window)",
  };
}

// ---------- Risk ----------

export type RiskReport = {
  score: number;
  level: RiskLevel;
  components: { name: string; weight: number; value: number; contribution: number }[];
  factors: {
    shortfallPct: number;
    gradeDeclinePct: number;
    uptimePct: number;
    reserveLifeYears: number;
    monsoonExposure: number;
    vegetationEncroachment: number;
  };
};

export async function assessRisk(mineId: number): Promise<RiskReport> {
  const [mine, hist, fc, sat] = await Promise.all([getMine(mineId), getProduction(mineId), forecastProduction(mineId), getSatellite(mineId)]);
  if (!mine) throw new Error("Mine not found");
  const first12 = hist.slice(0, 12);
  const last12 = hist.slice(-12);
  const g0 = first12.reduce((a, r) => a + r.gradeMnPct, 0) / 12;
  const g1 = last12.reduce((a, r) => a + r.gradeMnPct, 0) / 12;
  const uptime = last12.reduce((a, r) => a + r.equipmentUptimePct, 0) / 12;
  const monsoon = last12.filter((r) => r.month >= 7 && r.month <= 9);
  const nonMonsoon = last12.filter((r) => !(r.month >= 7 && r.month <= 9));
  const mAvg = monsoon.reduce((a, r) => a + r.producedKt, 0) / monsoon.length;
  const nAvg = nonMonsoon.reduce((a, r) => a + r.producedKt, 0) / nonMonsoon.length;
  const ndviFirst = sat.slice(0, 4).reduce((a, r) => a + r.ndvi, 0) / 4;
  const ndviLast = sat.slice(-4).reduce((a, r) => a + r.ndvi, 0) / 4;
  const factors = {
    shortfallPct: Math.max(0, fc.shortfallPct),
    gradeDeclinePct: +(((g0 - g1) / g0) * 100).toFixed(2),
    uptimePct: +uptime.toFixed(1),
    reserveLifeYears: +(mine.predictedReserveMt / Math.max(0.05, fc.forecastTotalMt)).toFixed(1),
    monsoonExposure: +Math.max(0, (nAvg - mAvg) / nAvg).toFixed(3),
    vegetationEncroachment: +Math.max(0, ndviLast - ndviFirst).toFixed(3),
  };
  const r = computeRiskScore(factors);
  return { ...r, factors };
}

// ---------- Recommendations (rule-based) ----------

export type Recommendation = {
  priority: "Immediate" | "Short-term" | "Strategic";
  title: string;
  rationale: string;
  impact: string;
  category: "Exploration" | "Operations" | "Planning" | "Environment" | "Maintenance";
};

export async function recommend(mineId: number) {
  const [mine, fc, risk, zonePreds] = await Promise.all([getMine(mineId), forecastProduction(mineId), assessRisk(mineId), predictZones(mineId)]);
  if (!mine) throw new Error("Mine not found");
  const recs: Recommendation[] = [];
  const high = zonePreds.filter((z) => z.zone.potential === "High").sort((a, b) => b.zone.probability - a.zone.probability);
  const low = zonePreds.filter((z) => z.zone.potential === "Low");

  if (fc.shortfallPct > 5 && high.length) {
    const z = high[0];
    recs.push({
      priority: "Immediate",
      category: "Exploration",
      title: `Fast-track development of Zone ${z.zone.code} (${z.zone.name})`,
      rationale: `Forecast shows a ${fc.shortfallPct}% shortfall against the ${fc.targetTotalMt} MT target. Zone ${z.zone.code} carries ${Math.round(z.zone.probability * 100)}% manganese probability with predicted grade ${z.predictedGradePct}% Mn and ~${z.predictedReserveMt} MT recoverable.`,
      impact: `Could recover an estimated ${(fc.targetTotalMt - fc.forecastTotalMt).toFixed(2)} MT gap within 12–18 months of bench development.`,
    });
  }
  if (fc.shortfallPct > 0) {
    recs.push({
      priority: "Short-term",
      category: "Planning",
      title: "Revise annual production plan and inform Ministry of Steel reporting",
      rationale: `Trend is ${fc.trendKtPerMonth} kt/month. Continuing on current benches will not meet the target.`,
      impact: "Avoids surprise shortfall; enables procurement and dispatch re-planning.",
    });
  }
  if (risk.factors.uptimePct < 86) {
    recs.push({
      priority: "Immediate",
      category: "Maintenance",
      title: "Launch preventive-maintenance drive on loading & haulage fleet",
      rationale: `Average equipment uptime is ${risk.factors.uptimePct}% (benchmark ≥ 90%). Downtime contributes ${risk.components.find((c) => c.name === "Equipment downtime")?.contribution ?? 0} points to the risk score.`,
      impact: "Each 1% uptime gain ≈ +0.3 kt/month output at current bench capacity.",
    });
  }
  if (risk.factors.monsoonExposure > 0.08) {
    recs.push({
      priority: "Short-term",
      category: "Operations",
      title: "Pre-monsoon stockpiling & dewatering readiness",
      rationale: `Production drops ${Math.round(risk.factors.monsoonExposure * 100)}% during Jul–Sep. Rainfall-driven downtime is recurring in the historical record.`,
      impact: "Build 6–8 weeks of ROM stockpile in Apr–Jun to smooth dispatch.",
    });
  }
  if (risk.factors.gradeDeclinePct > 2) {
    recs.push({
      priority: "Strategic",
      category: "Operations",
      title: "Blend feed with high-grade zone ore / expand beneficiation",
      rationale: `Mn grade has declined ${risk.factors.gradeDeclinePct}% over 5 years; low-grade feed reduces realisation per tonne.`,
      impact: "Maintains saleable grade ≥ 32% Mn for ferro-alloy customers.",
    });
  }
  if (low.length) {
    recs.push({
      priority: "Strategic",
      category: "Planning",
      title: `Deprioritise drilling in ${low.map((z) => "Zone " + z.zone.code).join(", ")}`,
      rationale: `Model probability ≤ ${Math.round(Math.max(...low.map((z) => z.zone.probability)) * 100)}% with thin, discontinuous intercepts. Exploration spend yields little reserve addition.`,
      impact: `Redirect ~₹${(low.length * 1.2).toFixed(1)} Cr of drilling budget to high-potential extensions.`,
    });
  }
  if (risk.factors.reserveLifeYears < 8) {
    recs.push({
      priority: "Strategic",
      category: "Exploration",
      title: "Commission satellite-guided regional exploration programme",
      rationale: `Reserve life at forecast rate is only ${risk.factors.reserveLifeYears} years. Sentinel-2 iron-oxide and clay anomalies flag unexplored targets around the lease.`,
      impact: "Targets reserve addition of 2–3 MT to extend mine life beyond 2040.",
    });
  }
  if (risk.factors.vegetationEncroachment > 0.05) {
    recs.push({
      priority: "Short-term",
      category: "Environment",
      title: "Update green-belt & land-use compliance report",
      rationale: `NDVI increased by ${risk.factors.vegetationEncroachment} across the lease — verify reclamation progress vs. encroachment on planned benches.`,
      impact: "Keeps EC/FC compliance current and de-risks expansion approvals.",
    });
  }
  const order = { Immediate: 0, "Short-term": 1, Strategic: 2 };
  recs.sort((a, b) => order[a.priority] - order[b.priority]);
  return { mine, forecast: fc, risk, zones: zonePreds, recommendations: recs };
}

// ---------- Dashboard overview ----------

export async function getOverview() {
  const ms = await getMines();
  const perMine = await Promise.all(
    ms.map(async (m: Mine) => {
      const [fc, risk] = await Promise.all([forecastProduction(m.id), assessRisk(m.id)]);
      return { mine: m, forecast: fc, risk };
    }),
  );
  const totalReserve = ms.reduce((a, m) => a + m.predictedReserveMt, 0);
  const totalForecast = perMine.reduce((a, p) => a + p.forecast.forecastTotalMt, 0);
  const totalTarget = perMine.reduce((a, p) => a + p.forecast.targetTotalMt, 0);
  const totalLastYear = perMine.reduce((a, p) => a + p.forecast.lastYearActualMt, 0);
  return {
    perMine,
    kpis: {
      predictedReserveMt: +totalReserve.toFixed(1),
      forecastMt: +totalForecast.toFixed(2),
      targetMt: +totalTarget.toFixed(2),
      lastYearMt: +totalLastYear.toFixed(2),
      shortfallPct: +(((totalTarget - totalForecast) / totalTarget) * 100).toFixed(1),
      avgRisk: Math.round(perMine.reduce((a, p) => a + p.risk.score, 0) / perMine.length),
      highRiskMines: perMine.filter((p) => p.risk.level === "High" || p.risk.level === "Critical").length,
    },
  };
}
