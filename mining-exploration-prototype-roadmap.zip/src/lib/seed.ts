import { db, pool } from "@/db";
import { mines, zones, drillholes, production, satelliteFeatures, equipment } from "@/db/schema";
import { sql } from "drizzle-orm";

// Deterministic PRNG so prototype data is stable between runs
function mulberry32(a: number) {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type MineSeed = {
  code: string;
  name: string;
  district: string;
  state: string;
  lat: number;
  lng: number;
  mineType: string;
  annualTargetMt: number;
  predictedReserveMt: number;
  avgGradeMnPct: number;
  activeSince: number;
  trend: number; // monthly production drift (kt/month)
  base: number; // base monthly production kt
  zones: { code: string; name: string; potential: "High" | "Medium" | "Low"; prob: number; reserve: number; grade: number; area: number; dLat: number; dLng: number; notes: string }[];
};

const MINES: MineSeed[] = [
  {
    code: "MINE-A",
    name: "Mine A — Dongri Buzurg",
    district: "Bhandara",
    state: "Maharashtra",
    lat: 21.4425,
    lng: 79.8467,
    mineType: "Opencast",
    annualTargetMt: 0.5,
    predictedReserveMt: 4.6,
    avgGradeMnPct: 34.2,
    activeSince: 1962,
    trend: -0.05,
    base: 40,
    zones: [
      { code: "A1", name: "North Bench", potential: "High", prob: 0.82, reserve: 1.9, grade: 36.1, area: 42, dLat: 0.006, dLng: -0.008, notes: "Consistent oxide-rich band; ideal for continued benching." },
      { code: "A2", name: "Central Pit", potential: "Medium", prob: 0.58, reserve: 1.4, grade: 33.0, area: 55, dLat: 0, dLng: 0, notes: "Depleting upper horizon; deeper drilling advised." },
      { code: "A3", name: "East Extension", potential: "Medium", prob: 0.52, reserve: 0.9, grade: 31.5, area: 38, dLat: 0.001, dLng: 0.011, notes: "Iron-oxide anomaly detected on Sentinel-2; unverified by drilling." },
      { code: "A4", name: "South Waste Dump", potential: "Low", prob: 0.21, reserve: 0.4, grade: 24.0, area: 30, dLat: -0.008, dLng: 0.002, notes: "Predominantly overburden. Low economic value." },
    ],
  },
  {
    code: "MINE-B",
    name: "Mine B — Balaghat",
    district: "Balaghat",
    state: "Madhya Pradesh",
    lat: 21.8135,
    lng: 80.1868,
    mineType: "Underground",
    annualTargetMt: 0.55,
    predictedReserveMt: 5.4,
    avgGradeMnPct: 38.5,
    activeSince: 1962,
    trend: -0.09,
    base: 44,
    zones: [
      { code: "B1", name: "West Shaft Block", potential: "Medium", prob: 0.61, reserve: 1.2, grade: 36.4, area: 40, dLat: 0.002, dLng: -0.012, notes: "Mature working; grade tapering below 380 m level." },
      { code: "B2", name: "Main Lode", potential: "Medium", prob: 0.66, reserve: 1.3, grade: 37.8, area: 48, dLat: -0.001, dLng: -0.002, notes: "Current primary production block." },
      { code: "B3", name: "North-East Lode Extension", potential: "High", prob: 0.91, reserve: 2.4, grade: 41.2, area: 52, dLat: 0.008, dLng: 0.009, notes: "Strong clay/iron-oxide anomaly + high-grade intercepts. Top exploration priority." },
      { code: "B4", name: "South Footwall", potential: "Low", prob: 0.27, reserve: 0.5, grade: 28.5, area: 34, dLat: -0.009, dLng: 0.004, notes: "Thin, discontinuous bands. Deprioritise." },
    ],
  },
  {
    code: "MINE-C",
    name: "Mine C — Chikla",
    district: "Bhandara",
    state: "Maharashtra",
    lat: 21.4105,
    lng: 79.7398,
    mineType: "Opencast",
    annualTargetMt: 0.35,
    predictedReserveMt: 2.8,
    avgGradeMnPct: 30.8,
    activeSince: 1975,
    trend: -0.02,
    base: 27,
    zones: [
      { code: "C1", name: "Upper Terrace", potential: "Medium", prob: 0.55, reserve: 0.9, grade: 31.0, area: 36, dLat: 0.006, dLng: 0.001, notes: "Steady low-grade feed for beneficiation." },
      { code: "C2", name: "River-side Block", potential: "High", prob: 0.78, reserve: 1.2, grade: 34.6, area: 44, dLat: -0.002, dLng: 0.010, notes: "Elevated Mn signature; monsoon flooding risk." },
      { code: "C3", name: "Old Quarry", potential: "Low", prob: 0.18, reserve: 0.3, grade: 22.0, area: 28, dLat: -0.007, dLng: -0.008, notes: "Largely mined out." },
      { code: "C4", name: "West Ridge", potential: "Medium", prob: 0.49, reserve: 0.4, grade: 29.5, area: 30, dLat: 0.003, dLng: -0.011, notes: "Satellite-derived target; requires drilling." },
    ],
  },
];

const ROCK_TYPES = ["Gondite", "Quartzite", "Mn-rich schist", "Laterite", "Phyllite"];

function polygonAround(lat: number, lng: number, rnd: () => number, scale = 0.0045) {
  const n = 6;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * Math.PI * 2;
    const r = scale * (0.75 + rnd() * 0.5);
    pts.push([+(lat + Math.sin(ang) * r).toFixed(5), +(lng + Math.cos(ang) * r * 1.1).toFixed(5)]);
  }
  return JSON.stringify(pts);
}

let seeded = false;
let seedingPromise: Promise<void> | null = null;

export async function ensureSeeded() {
  if (seeded) return;
  if (!seedingPromise) {
    seedingPromise = seedWithLock().finally(() => {
      seedingPromise = null;
    });
  }
  return seedingPromise;
}

async function seedWithLock() {
  // Advisory lock guards against concurrent seeding across requests/workers.
  // Session-level lock, so hold a dedicated client for lock + unlock.
  const client = await pool.connect();
  try {
    await client.query("select pg_advisory_lock(884201)");
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(mines);
    if (count === 0) await seedData();
    seeded = true;
  } finally {
    await client.query("select pg_advisory_unlock(884201)").catch(() => {});
    client.release();
  }
}

async function seedData() {
  const rnd = mulberry32(20240607);

  for (const m of MINES) {
    const [mine] = await db
      .insert(mines)
      .values({
        code: m.code,
        name: m.name,
        district: m.district,
        state: m.state,
        lat: m.lat,
        lng: m.lng,
        mineType: m.mineType,
        annualTargetMt: m.annualTargetMt,
        predictedReserveMt: m.predictedReserveMt,
        avgGradeMnPct: m.avgGradeMnPct,
        activeSince: m.activeSince,
      })
      .returning();

    // Zones
    const zoneRows = [];
    for (const z of m.zones) {
      const zLat = m.lat + z.dLat;
      const zLng = m.lng + z.dLng;
      const [zone] = await db
        .insert(zones)
        .values({
          mineId: mine.id,
          code: z.code,
          name: z.name,
          potential: z.potential,
          probability: z.prob,
          estReserveMt: z.reserve,
          avgGradeMnPct: z.grade,
          areaHa: z.area,
          ndvi: +(0.15 + (1 - z.prob) * 0.35 + rnd() * 0.05).toFixed(3),
          ironOxideIndex: +(0.9 + z.prob * 1.4 + rnd() * 0.1).toFixed(3),
          clayIndex: +(1.0 + z.prob * 0.9 + rnd() * 0.1).toFixed(3),
          polygon: polygonAround(zLat, zLng, rnd),
          notes: z.notes,
        })
        .returning();
      zoneRows.push({ zone, seed: z, zLat, zLng });
    }

    // Drill holes: 4 per zone
    let holeNo = 1;
    for (const { zone, seed: z, zLat, zLng } of zoneRows) {
      for (let i = 0; i < 4; i++) {
        const mn = z.grade + (rnd() - 0.5) * 8;
        await db.insert(drillholes).values({
          mineId: mine.id,
          zoneId: zone.id,
          holeId: `${m.code.replace("MINE-", "")}H-${String(holeNo++).padStart(3, "0")}`,
          lat: +(zLat + (rnd() - 0.5) * 0.005).toFixed(5),
          lng: +(zLng + (rnd() - 0.5) * 0.005).toFixed(5),
          depthM: +(m.mineType === "Underground" ? 180 + rnd() * 220 : 40 + rnd() * 90).toFixed(1),
          mnPct: +Math.max(15, mn).toFixed(2),
          fePct: +(6 + (1 - z.prob) * 10 + rnd() * 3).toFixed(2),
          sio2Pct: +(8 + (1 - z.prob) * 18 + rnd() * 4).toFixed(2),
          thicknessM: +(1.5 + z.prob * 6 + rnd() * 2).toFixed(2),
          rockType: ROCK_TYPES[Math.floor(rnd() * ROCK_TYPES.length)],
          drilledYear: 2019 + Math.floor(rnd() * 6),
        });
      }
    }

    // Production: Jan 2021 – Dec 2025 (60 months historical)
    const monthlyTarget = (m.annualTargetMt * 1000) / 12;
    let idx = 0;
    for (let year = 2021; year <= 2025; year++) {
      for (let month = 1; month <= 12; month++) {
        const monsoon = month >= 7 && month <= 9 ? -0.12 : 0;
        const rainfall = month >= 6 && month <= 9 ? 180 + rnd() * 160 : 5 + rnd() * 30;
        const uptime = 78 + rnd() * 16 - (month >= 7 && month <= 9 ? 5 : 0);
        const produced = m.base + m.trend * idx + m.base * monsoon + (rnd() - 0.5) * 5 + (uptime - 86) * 0.25;
        await db.insert(production).values({
          mineId: mine.id,
          year,
          month,
          producedKt: +Math.max(5, produced).toFixed(2),
          targetKt: +monthlyTarget.toFixed(2),
          gradeMnPct: +(m.avgGradeMnPct + (rnd() - 0.5) * 3 - idx * 0.02).toFixed(2),
          equipmentUptimePct: +uptime.toFixed(1),
          rainfallMm: +rainfall.toFixed(0),
          isForecast: false,
        });
        idx++;
      }
    }

    // Equipment fleet: 22 machines
    const fleet: [string, string, number][] = [
      ["Excavator", "E", 5],
      ["Dumper", "D", 8],
      ["Drill Rig", "R", 3],
      ["Wheel Loader", "L", 3],
      ["Crusher", "C", 2],
      ["Water Tanker", "W", 1],
    ];
    for (const [type, prefix, n] of fleet) {
      for (let i = 1; i <= n; i++) {
        const code = `${prefix}${String(i).padStart(2, "0")}`;
        let health = 70 + rnd() * 28;
        let status = "Healthy";
        let note: string | null = null;
        if (code === "E04") { health = 58; status = "Critical"; note = "Abnormal vibration and bearing temperature rising over 72 h."; }
        else if (code === "D03") { health = 66; status = "Warning"; note = "Hydraulic pressure drift; schedule inspection."; }
        else if (code === "R02") { health = 71; status = "Warning"; note = "Compressor efficiency down 9%."; }
        else if (code === "D07") { health = 80; status = "Maintenance"; note = "Planned 500-h service in progress."; }
        await db.insert(equipment).values({
          mineId: mine.id,
          code,
          name: `${type} ${code}`,
          type,
          status,
          healthScore: +health.toFixed(0),
          vibrationMmS: +(status === "Critical" ? 9.4 : status === "Warning" ? 5.1 + rnd() : 2 + rnd() * 2).toFixed(1),
          temperatureC: +(status === "Critical" ? 96 : 68 + rnd() * 14).toFixed(0),
          runtimeHours: +(4000 + rnd() * 9000).toFixed(0),
          lastServiceDays: Math.floor(rnd() * 90),
          note,
        });
      }
    }

    // Satellite features: quarterly 2021-2025
    for (let year = 2021; year <= 2025; year++) {
      for (const q of [1, 4, 7, 10]) {
        await db.insert(satelliteFeatures).values({
          mineId: mine.id,
          captureDate: `${year}-${String(q).padStart(2, "0")}-15`,
          sensor: rnd() > 0.5 ? "Sentinel-2 MSI" : "Landsat-8 OLI",
          ndvi: +(0.2 + (q >= 7 ? 0.2 : 0) + rnd() * 0.08).toFixed(3),
          ironOxideIndex: +(1.6 + rnd() * 0.3).toFixed(3),
          clayIndex: +(1.4 + rnd() * 0.3).toFixed(3),
          bareSoilIndex: +(0.3 + rnd() * 0.15 + (year - 2021) * 0.02).toFixed(3),
          landSurfaceTempC: +(28 + (q === 4 ? 10 : q === 1 ? -3 : 3) + rnd() * 3).toFixed(1),
          cloudCoverPct: +(q === 7 ? 40 + rnd() * 40 : rnd() * 15).toFixed(0),
        });
      }
    }
  }
  seeded = true;
}
