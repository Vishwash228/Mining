import { cookies } from "next/headers";
import { getMines } from "./analytics";

export const SESSION_COOKIE = "moil_session";
export const MINE_COOKIE = "moil_mine";

export const DEMO_USERS: Record<string, { password: string; name: string; role: string }> = {
  manager: { password: "vision123", name: "Rajesh Deshmukh", role: "Mine Manager" },
  geologist: { password: "vision123", name: "Dr. Anita Rao", role: "Geologist" },
  production: { password: "vision123", name: "Suresh Patil", role: "Production Manager" },
  maintenance: { password: "vision123", name: "Imran Sheikh", role: "Maintenance Engineer" },
  admin: { password: "vision123", name: "System Admin", role: "Administrator" },
};

export async function getSessionUser() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [username] = token.split(":");
  const u = DEMO_USERS[username];
  return u ? { username, ...u } : null;
}

/** Returns the currently selected mine (falls back to Mine B for the demo story). */
export async function getSelectedMine() {
  const store = await cookies();
  const raw = store.get(MINE_COOKIE)?.value;
  const all = await getMines();
  const id = raw ? Number(raw) : NaN;
  return all.find((m) => m.id === id) ?? all.find((m) => m.code === "MINE-B") ?? all[0];
}
