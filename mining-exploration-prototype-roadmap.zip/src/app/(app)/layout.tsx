import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { getSelectedMine, getSessionUser } from "@/lib/session";
import { getMines, recommend } from "@/lib/analytics";
import { DemoBanner } from "@/components/ui";
import HeaderBar from "@/components/HeaderBar";
import EntryShell from "@/components/EntryShell";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const [allMines, selected] = await Promise.all([getMines(), getSelectedMine()]);
  const { recommendations } = await recommend(selected.id);
  const alerts = recommendations.filter((r) => r.priority === "Immediate").length + 2;

  return (
    <EntryShell>
      <Sidebar />
      <div className="flex-1 min-w-0 flex flex-col">
        <HeaderBar mines={allMines.map((m) => ({ id: m.id, name: m.name, code: m.code }))} selectedId={selected.id} user={{ name: user.name, role: user.role }} alerts={alerts} />
        <main className="p-6 max-w-[1440px] w-full mx-auto text-slate-100">
          <div className="mb-4 no-print"><DemoBanner /></div>
          {children}
        </main>
      </div>
    </EntryShell>
  );
}
