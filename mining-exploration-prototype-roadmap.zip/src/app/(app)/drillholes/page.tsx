import { getReserveModel, predictZones, RESERVE_FEATURES } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, NextStep, PageHeader, PotentialBadge, potentialColor } from "@/components/ui";
import { GradeDepthScatter, ZoneGradeBars, ImportanceBars } from "@/components/charts/DrillholeCharts";
import PredictPlayground from "@/components/PredictPlayground";

export default async function DrillholesPage({ searchParams }: { searchParams: Promise<{ zone?: string }> }) {
  const [{ zone: zoneFilter }, mine] = await Promise.all([searchParams, getSelectedMine()]);
  const [preds, { model, r2, n }] = await Promise.all([predictZones(mine.id), getReserveModel()]);
  const visible = zoneFilter ? preds.filter((p) => p.zone.code === zoneFilter) : preds;
  const rows = visible.flatMap((p) => p.holes.map((h) => ({ ...h, zone: p.zone.code, potential: p.zone.potential })));
  const totalReserve = preds.reduce((a, p) => a + p.predictedReserveMt, 0);

  return (
    <>
      <PageHeader
        step="Step 4 · Drill-hole Analysis"
        title={`${mine.name} — Drill-hole Analysis`}
        description="Borehole intercepts feed the Random Forest reserve model together with satellite indices. Left: raw drill logs. Right: model outputs."
      >
        <div className="flex gap-2 items-center">
          {zoneFilter && (
            <a href="/drillholes" className="text-xs text-slate-500 underline">
              Clear filter (Zone {zoneFilter})
            </a>
          )}
          <NextStep href="/forecast" label="Production forecast" />
        </div>
      </PageHeader>

      <div className="grid lg:grid-cols-5 gap-4">
        <Card title={`Drill logs (${rows.length})`} subtitle="drillholes.csv — prototype sample data" className="lg:col-span-3">
          <div className="overflow-auto max-h-[520px]">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-white">
                <tr className="text-left uppercase text-slate-500 border-b">
                  <th className="py-2">Hole</th>
                  <th>Zone</th>
                  <th className="text-right">Depth m</th>
                  <th className="text-right">Mn %</th>
                  <th className="text-right">Fe %</th>
                  <th className="text-right">SiO₂ %</th>
                  <th className="text-right">Thick. m</th>
                  <th>Rock</th>
                  <th className="text-right">Year</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((h) => (
                  <tr key={h.holeId} className="border-b last:border-0 hover:bg-slate-50">
                    <td className="py-1.5 font-mono font-semibold">{h.holeId}</td>
                    <td>
                      <span className="inline-flex items-center gap-1">
                        <span className="h-2 w-2 rounded-sm" style={{ background: potentialColor[h.potential] }} />
                        {h.zone}
                      </span>
                    </td>
                    <td className="text-right">{h.depthM}</td>
                    <td className={`text-right font-semibold ${h.mnPct >= 35 ? "text-emerald-700" : h.mnPct < 28 ? "text-red-600" : ""}`}>{h.mnPct}</td>
                    <td className="text-right">{h.fePct}</td>
                    <td className="text-right">{h.sio2Pct}</td>
                    <td className="text-right">{h.thicknessM}</td>
                    <td>{h.rockType}</td>
                    <td className="text-right">{h.drilledYear}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <Card title="Random Forest reserve model" subtitle={`RandomForestRegressor · ${n} intercepts · train R² ${r2.toFixed(2)}`}>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="rounded-lg bg-orange-50 p-3">
                <div className="text-[11px] text-slate-500">Predicted mine reserve</div>
                <div className="text-2xl font-bold text-orange-600">{totalReserve.toFixed(2)} MT</div>
              </div>
              <div className="rounded-lg bg-slate-50 p-3">
                <div className="text-[11px] text-slate-500">Inputs</div>
                <div className="text-xs font-medium leading-snug">depth, thickness, Fe, SiO₂ + NDVI, iron-oxide, clay index</div>
              </div>
            </div>
            <div className="text-xs font-semibold text-slate-500 mb-1">Feature importance</div>
            <ImportanceBars data={RESERVE_FEATURES.map((f, i) => ({ feature: f, importance: model.featureImportances()[i] }))} />
          </Card>
          <Card title="Grade vs depth" subtitle="Bubble size = seam thickness">
            <GradeDepthScatter data={rows.map((h) => ({ holeId: h.holeId, depthM: h.depthM, mnPct: h.mnPct, thicknessM: h.thicknessM, zone: h.zone, color: potentialColor[h.potential] }))} />
          </Card>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card title="Zone-level prediction" subtitle="Measured vs Random-Forest-predicted grade">
          <ZoneGradeBars
            data={preds.map((p) => ({
              zone: p.zone.code,
              measured: +(p.holes.reduce((a, h) => a + h.mnPct, 0) / Math.max(1, p.holes.length)).toFixed(2),
              predicted: p.predictedGradePct,
              color: potentialColor[p.zone.potential],
            }))}
          />
          <table className="w-full text-xs mt-2">
            <thead>
              <tr className="text-left text-slate-500 border-b">
                <th className="py-1">Zone</th>
                <th>Potential</th>
                <th className="text-right">Prob.</th>
                <th className="text-right">Pred. grade</th>
                <th className="text-right">Pred. reserve</th>
                <th className="text-right">Conf.</th>
              </tr>
            </thead>
            <tbody>
              {preds.map((p) => (
                <tr key={p.zone.id} className="border-b last:border-0">
                  <td className="py-1 font-semibold">{p.zone.code}</td>
                  <td>
                    <PotentialBadge level={p.zone.potential} />
                  </td>
                  <td className="text-right">{Math.round(p.zone.probability * 100)}%</td>
                  <td className="text-right">{p.predictedGradePct}%</td>
                  <td className="text-right">{p.predictedReserveMt} MT</td>
                  <td className="text-right">{p.confidence}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card title="Try the model (live inference)" subtitle="POST /api/predict — change inputs and see the Random Forest respond">
          <PredictPlayground />
        </Card>
      </div>
    </>
  );
}
