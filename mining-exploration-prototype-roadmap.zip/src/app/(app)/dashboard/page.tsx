import { getOverview, getTodaySnapshot, predictZones } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card } from "@/components/ui";
import { TodayChart } from "@/components/charts/TodayChart";
import MapClient from "@/components/map/MapClient";

export default async function DashboardPage() {
  const mine = await getSelectedMine();
  const [today, preds, overview] = await Promise.all([getTodaySnapshot(mine.id), predictZones(mine.id), getOverview()]);
  const mineOverview = overview.perMine.find((p) => p.mine.id === mine.id)!;
  const reserveT = Math.round(mine.predictedReserveMt * 1e6);
  const confidence = Math.round(preds.reduce((a, p) => a + p.confidence, 0) / preds.length);
  const gradeAvg = +(preds.reduce((a, p) => a + p.predictedGradePct * p.zone.areaHa, 0) / preds.reduce((a, p) => a + p.zone.areaHa, 0)).toFixed(1);
  const e04 = today.critical[0];

  const zones = preds.map((p) => ({
    id: p.zone.id, code: p.zone.code, name: p.zone.name, potential: p.zone.potential, probability: p.zone.probability,
    estReserveMt: p.zone.estReserveMt, predictedReserveMt: p.predictedReserveMt, predictedGradePct: p.predictedGradePct, gradeStd: p.gradeStd,
    confidence: p.confidence, areaHa: p.zone.areaHa, ndvi: p.zone.ndvi, ironOxideIndex: p.zone.ironOxideIndex, clayIndex: p.zone.clayIndex,
    polygon: JSON.parse(p.zone.polygon) as [number, number][], notes: p.zone.notes,
    holes: p.holes.map((h) => ({ holeId: h.holeId, lat: h.lat, lng: h.lng, mnPct: h.mnPct, depthM: h.depthM, thicknessM: h.thicknessM })),
  }));

  const statusTone = (s: string) => (s === "HIGH" ? "text-red-600" : s === "MODERATE" || s === "MEDIUM" ? "text-amber-600" : "text-emerald-600");

  return (
    <>
      <div className="flex items-end justify-between mb-5">
        <div>
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-[0.25em]">Vision Craft</div>
          <h1 className="text-2xl font-bold text-white">{mine.name}</h1>
          <p className="text-sm text-slate-400">{mine.district}, {mine.state} · {mine.mineType} · Live operational intelligence</p>
        </div>
        <a href="/map" className="no-print rounded-lg bg-amber-500 text-[#0b1526] px-4 py-2 text-sm font-semibold hover:bg-amber-400">Open Potential Map →</a>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiCard label="Estimated Material" value={`${reserveT.toLocaleString("en-US")} T`} sub={`Confidence: ${confidence}%`} tone="text-amber-600" />
        <KpiCard label="Average Mn Grade" value={`${gradeAvg}%`} sub={`Mine avg ${mine.avgGradeMnPct}% · RF model`} />
        <KpiCard label="Today's Production" value={`${today.currentT.toLocaleString("en-US")} T`} sub={`Target: ${today.targetT.toLocaleString("en-US")} T`} progress={today.currentT / today.targetT} />
        <KpiCard label="Shortfall Risk" value={today.shortfallLevel} tone={statusTone(today.shortfallLevel)} sub={`Predicted: ${today.predictedT.toLocaleString("en-US")} T · Gap: ${today.shortfallT.toLocaleString("en-US")} T`} />
        <KpiCard label="Equipment Health" value={`${today.fleetHealth}%`} sub={`${today.healthy} / ${today.fleet.length} Healthy`} tone={today.fleetHealth >= 85 ? "text-emerald-600" : "text-amber-600"} progress={today.healthy / today.fleet.length} />
        <KpiCard label="Environmental Status" value={today.envStatus} tone={statusTone(today.envStatus)} sub={`Rainfall: ${today.rainfallMm} mm · Soil Moisture: ${today.soilMoisture}`} />
      </div>

      <div className="grid xl:grid-cols-3 gap-4 mt-4">
        <div className="vc-map xl:col-span-2 space-y-4">
          <Card title="Mine Map" subtitle="Boundary · drill holes · Mn grade zones · kriging prediction · satellite layer">
            <MapClient center={[mine.lat, mine.lng]} mineName={mine.name} zones={zones} compact />
            <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-600">
              {[["#dc2626", "Low Grade"], ["#f59e0b", "Medium Grade"], ["#16a34a", "High Grade"], ["#065f46", "Very High Grade"]].map(([c, l]) => (
                <span key={l} className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm" style={{ background: c }} />{l}</span>
              ))}
              <span className="ml-auto text-slate-400">Controls: + − · Satellite · Geological · Grade (layer switcher, top-right)</span>
            </div>
          </Card>
          <div className="vc-chart">
            <Card title="Production — Target vs Actual vs Predicted" subtitle="Today's shift, tonnes (cumulative)">
              <div className="grid grid-cols-4 gap-3 mb-3 text-center">
                <Mini label="Target" value={`${today.targetT.toLocaleString("en-US")} T`} />
                <Mini label="Current" value={`${today.currentT.toLocaleString("en-US")} T`} />
                <Mini label="Predicted" value={`${today.predictedT.toLocaleString("en-US")} T`} accent />
                <Mini label="Potential Shortfall" value={`${today.shortfallT.toLocaleString("en-US")} T`} bad={today.shortfallT > 0} />
              </div>
              <TodayChart points={today.points} />
            </Card>
          </div>
        </div>

        {/* AI Insights */}
        <div className="vc-insights">
          <div className="rounded-xl bg-gradient-to-b from-[#132238] to-[#0b1526] border border-amber-500/30 shadow-lg p-5 text-white space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black tracking-[0.2em] text-amber-400">AI INSIGHTS</h3>
              <span className="text-[10px] text-slate-400">{mineOverview.risk.level} risk · {mineOverview.risk.score}/100</span>
            </div>

            <Insight tone="red" title="Production Shortfall Risk" body="Predicted production is below today's target.">
              <div className="text-2xl font-bold text-red-300">{today.shortfallT.toLocaleString("en-US")} T <span className="text-xs text-slate-400 font-normal">potential shortfall</span></div>
              <div className="text-xs text-slate-300 mt-2">Contributing factors:</div>
              <ul className="text-xs text-slate-300 list-disc pl-4">
                <li>Equipment downtime ({today.fleet.length - today.healthy} units degraded)</li>
                <li>Heavy rainfall ({today.rainfallMm} mm)</li>
                <li>Blasting delay (10:00–12:00)</li>
              </ul>
              <a href="/risk" className="mt-3 inline-block text-[11px] font-bold tracking-wider bg-amber-500 text-[#0b1526] px-3 py-1.5 rounded-md hover:bg-amber-400">VIEW DETAILS</a>
            </Insight>

            <Insight tone="amber" title="Equipment Risk" body={e04 ? `${e04.name} shows abnormal vibration (${e04.vibrationMmS} mm/s) and temperature (${e04.temperatureC} °C).` : "All machines within limits."}>
              <a href="/equipment" className="mt-2 inline-block text-[11px] font-bold tracking-wider border border-amber-400 text-amber-300 px-3 py-1.5 rounded-md hover:bg-amber-500/10">INSPECT EQUIPMENT</a>
            </Insight>

            <Insight tone="blue" title="Environmental Alert" body={`High rainfall (${today.rainfallMm} mm) may affect haul-road and pit operating conditions.`}>
              <a href="/satellite" className="mt-2 inline-block text-[11px] font-bold tracking-wider border border-sky-400 text-sky-300 px-3 py-1.5 rounded-md hover:bg-sky-500/10">VIEW SATELLITE DATA</a>
            </Insight>

            <a href="/recommendations" className="block text-center text-xs text-slate-400 hover:text-white pt-1">See all AI recommendations →</a>
          </div>
        </div>
      </div>
    </>
  );
}

function KpiCard({ label, value, sub, tone = "text-slate-900", progress }: { label: string; value: string; sub: string; tone?: string; progress?: number }) {
  return (
    <div className="vc-kpi vc-card-hover bg-white rounded-xl border border-slate-200 shadow-sm p-4 text-slate-900">
      <div className="text-[11px] uppercase tracking-wide text-slate-500 font-medium">{label}</div>
      <div className={`mt-1.5 text-2xl font-bold ${tone}`}>{value}</div>
      <div className="mt-1 text-[11px] text-slate-500">{sub}</div>
      {progress !== undefined && (
        <div className="mt-2 h-1.5 rounded-full bg-slate-100 overflow-hidden">
          <div className={`h-full ${progress >= 0.9 ? "bg-emerald-500" : progress >= 0.75 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${Math.min(100, progress * 100)}%` }} />
        </div>
      )}
    </div>
  );
}
function Mini({ label, value, accent, bad }: { label: string; value: string; accent?: boolean; bad?: boolean }) {
  return (
    <div className="rounded-lg bg-slate-50 p-2">
      <div className="text-[10px] text-slate-500">{label}</div>
      <div className={`font-bold text-sm ${accent ? "text-amber-600" : bad ? "text-red-600" : "text-slate-800"}`}>{value}</div>
    </div>
  );
}
function Insight({ tone, title, body, children }: { tone: "red" | "amber" | "blue"; title: string; body: string; children: React.ReactNode }) {
  const border = { red: "border-red-400/40", amber: "border-amber-400/40", blue: "border-sky-400/40" }[tone];
  const dot = { red: "bg-red-400", amber: "bg-amber-400", blue: "bg-sky-400" }[tone];
  return (
    <div className={`rounded-lg border ${border} bg-white/[0.04] p-4`}>
      <div className="flex items-center gap-2 font-semibold text-sm"><span className={`h-2 w-2 rounded-full ${dot}`} />{title}</div>
      <p className="text-xs text-slate-300 mt-1">{body}</p>
      <div className="mt-2">{children}</div>
    </div>
  );
}
