import { getOverview } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { PageHeader, RiskBadge } from "@/components/ui";

export default async function MinesPage() {
  const [{ perMine }, selected] = await Promise.all([getOverview(), getSelectedMine()]);
  return (
    <>
      <PageHeader step="Step 2 · Select Mine" title="Choose a mine to analyse" description="All downstream screens (map, drill-holes, forecast, risk, recommendation) follow the selected mine." />
      <div className="grid md:grid-cols-3 gap-4">
        {perMine.map((p) => {
          const active = p.mine.id === selected.id;
          return (
            <a
              key={p.mine.id}
              href={`/api/select-mine?id=${p.mine.id}&next=/map`}
              className={`block rounded-2xl border-2 p-5 bg-white text-slate-900 shadow-sm hover:shadow-md transition ${active ? "border-orange-500" : "border-slate-200 hover:border-slate-300"}`}
            >
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold text-slate-500">{p.mine.code}</div>
                {active && <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">SELECTED</span>}
              </div>
              <h3 className="text-lg font-bold mt-1">{p.mine.name}</h3>
              <p className="text-xs text-slate-500">
                {p.mine.district}, {p.mine.state} · {p.mine.mineType} · since {p.mine.activeSince}
              </p>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt className="text-xs text-slate-500">Predicted reserve</dt>
                  <dd className="font-semibold">{p.mine.predictedReserveMt.toFixed(1)} MT</dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500">Avg grade</dt>
                  <dd className="font-semibold">{p.mine.avgGradeMnPct.toFixed(1)}% Mn</dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500">12-mo forecast</dt>
                  <dd className="font-semibold">
                    {p.forecast.forecastTotalMt.toFixed(2)} / {p.forecast.targetTotalMt.toFixed(2)} MT
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500">Risk</dt>
                  <dd className="font-semibold flex items-center gap-2">
                    {p.risk.score} <RiskBadge level={p.risk.level} />
                  </dd>
                </div>
              </dl>
              <div className="mt-4 text-sm font-semibold text-orange-600">Open potential map →</div>
            </a>
          );
        })}
      </div>
    </>
  );
}
