import { recommend } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, NextStep, PageHeader, RiskBadge } from "@/components/ui";

const PRIORITY_STYLE = {
  Immediate: "bg-red-600 text-white",
  "Short-term": "bg-amber-500 text-white",
  Strategic: "bg-[#0b1f3a] text-white",
};
const CAT_ICON: Record<string, string> = { Exploration: "⛏", Operations: "⚙", Planning: "▦", Environment: "🌱", Maintenance: "🔧" };

export default async function RecommendationsPage() {
  const mine = await getSelectedMine();
  const { forecast, risk, zones, recommendations } = await recommend(mine.id);
  const top = [...zones].sort((a, b) => b.zone.probability - a.zone.probability)[0];

  return (
    <>
      <PageHeader
        step="Step 7 · AI Recommendation"
        title={`${mine.name} — What should MOIL do?`}
        description="The rule engine converts model outputs (forecast gap, risk drivers, zone potential) into prioritised, quantified actions."
      >
        <NextStep href="/reports" label="Generate report" />
      </PageHeader>

      <div className="rounded-2xl bg-gradient-to-r from-[#0b1f3a] to-[#1d3a66] text-white p-6 grid md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <div className="text-xs uppercase tracking-wider text-slate-300">Situation summary</div>
          <p className="mt-2 text-lg font-semibold leading-snug">
            Production at {mine.name.split(" — ")[0]} is forecast at <span className="text-orange-400">{forecast.forecastTotalMt.toFixed(2)} MT</span> vs a {forecast.targetTotalMt.toFixed(2)} MT target — a{" "}
            <span className="text-orange-400">{forecast.shortfallPct}% shortfall</span>. Risk is <span className="text-orange-400">{risk.level}</span> ({risk.score}/100).
          </p>
          <p className="mt-2 text-sm text-slate-300">
            Highest-potential zone: <b className="text-white">Zone {top.zone.code} ({top.zone.name})</b> — {Math.round(top.zone.probability * 100)}% Mn probability, predicted {top.predictedGradePct}% Mn, ~{top.predictedReserveMt} MT.
          </p>
        </div>
        <Stat label="Forecast gap" value={`${(forecast.targetTotalMt - forecast.forecastTotalMt).toFixed(3)} MT`} />
        <Stat label="Actions generated" value={`${recommendations.length}`} sub={`${recommendations.filter((r) => r.priority === "Immediate").length} immediate`} />
      </div>

      <div className="grid gap-4 mt-4">
        {recommendations.map((r, i) => (
          <div key={i} className="bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm p-5 flex gap-4">
            <div className="shrink-0 h-12 w-12 rounded-xl bg-slate-100 grid place-items-center text-2xl">{CAT_ICON[r.category]}</div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${PRIORITY_STYLE[r.priority]}`}>{r.priority.toUpperCase()}</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600">{r.category}</span>
                <span className="text-[10px] text-slate-400">#{i + 1}</span>
              </div>
              <h3 className="mt-1 font-bold text-slate-900">{r.title}</h3>
              <p className="mt-1 text-sm text-slate-600">
                <b className="text-slate-800">Why:</b> {r.rationale}
              </p>
              <p className="mt-1 text-sm text-emerald-700">
                <b>Expected impact:</b> {r.impact}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card title="Rule engine (prototype)" subtitle="Transparent, auditable logic — upgradeable to an LLM/optimisation layer later">
          <ul className="text-xs font-mono space-y-1.5 text-slate-700">
            <li>IF shortfall &gt; 5% AND high_potential_zone → fast-track zone development</li>
            <li>IF shortfall &gt; 0% → revise annual plan / reporting</li>
            <li>IF uptime &lt; 86% → preventive-maintenance drive</li>
            <li>IF monsoon_drop &gt; 8% → pre-monsoon stockpiling</li>
            <li>IF grade_decline &gt; 2% → blending / beneficiation</li>
            <li>IF low_potential_zones → deprioritise drilling, redirect budget</li>
            <li>IF reserve_life &lt; 8 yrs → satellite-guided regional exploration</li>
            <li>IF ΔNDVI &gt; 0.05 → land-use compliance update</li>
          </ul>
        </Card>
        <Card title="Inputs to this recommendation" subtitle="Traceability">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <Trace k="Forecast model" v={forecast.model} />
            <Trace k="Risk level" v={<RiskBadge level={risk.level} />} />
            <Trace k="Shortfall" v={`${forecast.shortfallPct}%`} />
            <Trace k="Uptime" v={`${risk.factors.uptimePct}%`} />
            <Trace k="Grade decline" v={`${risk.factors.gradeDeclinePct}%`} />
            <Trace k="Reserve life" v={`${risk.factors.reserveLifeYears} yrs`} />
            <Trace k="Monsoon drop" v={`${Math.round(risk.factors.monsoonExposure * 100)}%`} />
            <Trace k="Zones evaluated" v={`${zones.length}`} />
          </div>
        </Card>
      </div>
    </>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl bg-white/10 p-4">
      <div className="text-xs text-slate-300">{label}</div>
      <div className="text-2xl font-bold">{value}</div>
      {sub && <div className="text-xs text-slate-300">{sub}</div>}
    </div>
  );
}
function Trace({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="rounded-lg bg-slate-50 p-2">
      <div className="text-[11px] text-slate-500">{k}</div>
      <div className="font-semibold text-xs">{v}</div>
    </div>
  );
}
