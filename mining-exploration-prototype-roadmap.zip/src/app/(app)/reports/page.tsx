import { recommend } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, PageHeader, PotentialBadge, RiskBadge } from "@/components/ui";
import PrintButton from "@/components/PrintButton";

export default async function ReportsPage() {
  const mine = await getSelectedMine();
  const { forecast, risk, zones, recommendations } = await recommend(mine.id);
  const generated = new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

  return (
    <>
      <PageHeader step="Reports" title={`${mine.name} — Decision Support Report`} description="One-page summary for management. Use Print / Save as PDF.">
        <PrintButton />
      </PageHeader>

      <div className="bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm p-8 space-y-6 print:shadow-none print:border-0">
        <div className="flex items-start justify-between border-b pb-4">
          <div>
            <div className="text-xs font-semibold text-orange-600">VISION CRAFT · MINING INTELLIGENCE · PROTOTYPE REPORT</div>
            <h2 className="text-2xl font-bold">{mine.name}</h2>
            <div className="text-sm text-slate-500">
              {mine.district}, {mine.state} · {mine.mineType} · Generated {generated}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-500">Overall risk</div>
            <div className="text-3xl font-black">{risk.score}</div>
            <RiskBadge level={risk.level} />
          </div>
        </div>

        <section>
          <h3 className="font-bold mb-2">1. Executive summary</h3>
          <p className="text-sm text-slate-700">
            The AI model predicts a total reserve of <b>{mine.predictedReserveMt.toFixed(1)} MT</b> at an average grade of {mine.avgGradeMnPct}% Mn. Production over the next 12 months is forecast at{" "}
            <b>{forecast.forecastTotalMt.toFixed(2)} MT</b> against a target of {forecast.targetTotalMt.toFixed(2)} MT, an expected shortfall of <b>{forecast.shortfallPct}%</b>. The composite risk score is{" "}
            <b>
              {risk.score}/100 ({risk.level})
            </b>
            , driven mainly by {risk.components.slice().sort((a, b) => b.contribution - a.contribution)[0].name.toLowerCase()}.
          </p>
        </section>

        <section>
          <h3 className="font-bold mb-2">2. Zone potential</h3>
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-slate-500 border-b">
                <th className="py-1">Zone</th>
                <th>Potential</th>
                <th className="text-right">Probability</th>
                <th className="text-right">Pred. grade</th>
                <th className="text-right">Pred. reserve</th>
                <th className="text-right">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {zones.map((z) => (
                <tr key={z.zone.id} className="border-b last:border-0">
                  <td className="py-1 font-semibold">
                    {z.zone.code} · {z.zone.name}
                  </td>
                  <td>
                    <PotentialBadge level={z.zone.potential} />
                  </td>
                  <td className="text-right">{Math.round(z.zone.probability * 100)}%</td>
                  <td className="text-right">{z.predictedGradePct}%</td>
                  <td className="text-right">{z.predictedReserveMt} MT</td>
                  <td className="text-right">{z.confidence}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-bold mb-2">3. Production forecast</h3>
            <ul className="text-sm space-y-1">
              <li>Model: {forecast.model}</li>
              <li>Trend: {forecast.trendKtPerMonth} kt/month</li>
              <li>Last 12 months actual: {forecast.lastYearActualMt.toFixed(2)} MT</li>
              <li>Next 12 months forecast: {forecast.forecastTotalMt.toFixed(2)} MT</li>
              <li>Gap to target: {(forecast.targetTotalMt - forecast.forecastTotalMt).toFixed(3)} MT</li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-2">4. Risk drivers</h3>
            <ul className="text-sm space-y-1">
              {risk.components.map((c) => (
                <li key={c.name} className="flex justify-between">
                  <span>{c.name}</span>
                  <span className="font-semibold">{c.contribution} pts</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section>
          <h3 className="font-bold mb-2">5. Recommended actions</h3>
          <ol className="space-y-2 text-sm list-decimal pl-5">
            {recommendations.map((r, i) => (
              <li key={i}>
                <b>[{r.priority}]</b> {r.title} — <span className="text-slate-600">{r.impact}</span>
              </li>
            ))}
          </ol>
        </section>

        <div className="text-[11px] text-slate-500 border-t pt-3">
          Prototype output on synthetic demo data. Reserve figures are model estimates for decision support and do not constitute certified reserves under UNFC/JORC.
        </div>
      </div>
    </>
  );
}
