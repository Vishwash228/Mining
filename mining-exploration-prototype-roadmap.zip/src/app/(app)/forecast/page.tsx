import { forecastProduction, getProduction, MONTHS } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, Kpi, NextStep, PageHeader } from "@/components/ui";
import { ForecastChart } from "@/components/charts/ForecastChart";

export default async function ForecastPage() {
  const mine = await getSelectedMine();
  const [fc, hist] = await Promise.all([forecastProduction(mine.id), getProduction(mine.id)]);
  const years = Array.from(new Set(hist.map((h) => h.year)));
  const annual = years.map((y) => {
    const rows = hist.filter((h) => h.year === y);
    return { year: y, produced: rows.reduce((a, r) => a + r.producedKt, 0) / 1000, target: rows.reduce((a, r) => a + r.targetKt, 0) / 1000 };
  });
  const future = fc.points.filter((p) => p.actual === null);
  const tone = fc.shortfallPct > 10 ? "bad" : fc.shortfallPct > 5 ? "warn" : "good";

  return (
    <>
      <PageHeader
        step="Step 5 · Production Forecast"
        title={`${mine.name} — Production Forecast`}
        description={`${fc.model}. Trained on monthly production, equipment uptime and rainfall; predicts the next 12 months with a 90% uncertainty band.`}
      >
        <NextStep href="/risk" label="Risk detection" />
      </PageHeader>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi label="12-month forecast" value={fc.forecastTotalMt.toFixed(2)} unit="MT" hint={`Last 12 months actual: ${fc.lastYearActualMt.toFixed(2)} MT`} tone="brand" />
        <Kpi label="Annual target" value={fc.targetTotalMt.toFixed(2)} unit="MT" hint={`${mine.annualTargetMt} MT/yr plan`} />
        <Kpi label="Expected shortfall" value={`${fc.shortfallPct}%`} hint={`${(fc.targetTotalMt - fc.forecastTotalMt).toFixed(3)} MT gap`} tone={tone} />
        <Kpi label="Trend" value={`${fc.trendKtPerMonth > 0 ? "+" : ""}${fc.trendKtPerMonth}`} unit="kt/mo" hint={`RMSE ${fc.rmse} kt`} tone={fc.trendKtPerMonth < 0 ? "bad" : "good"} />
      </div>

      <Card title="Actual vs forecast (monthly, kt)" subtitle="Last 24 months actual + next 12 months forecast" className="mt-4">
        <ForecastChart points={fc.points} />
      </Card>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card title="Monthly forecast table" subtitle="kt = thousand tonnes">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-slate-500 border-b">
                <th className="py-1">Month</th>
                <th className="text-right">Forecast</th>
                <th className="text-right">Low</th>
                <th className="text-right">High</th>
                <th className="text-right">Target</th>
                <th className="text-right">Gap</th>
              </tr>
            </thead>
            <tbody>
              {future.map((p) => {
                const gap = (p.forecast ?? 0) - p.target;
                return (
                  <tr key={p.label} className="border-b last:border-0">
                    <td className="py-1">{MONTHS[p.month - 1]} {p.year}</td>
                    <td className="text-right font-semibold">{p.forecast?.toFixed(1)}</td>
                    <td className="text-right text-slate-500">{p.lower?.toFixed(1)}</td>
                    <td className="text-right text-slate-500">{p.upper?.toFixed(1)}</td>
                    <td className="text-right">{p.target.toFixed(1)}</td>
                    <td className={`text-right font-semibold ${gap < 0 ? "text-red-600" : "text-emerald-600"}`}>{gap > 0 ? "+" : ""}{gap.toFixed(1)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
        <Card title="Annual history" subtitle="Production vs target by year (MT)">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-slate-500 border-b">
                <th className="py-1">Year</th>
                <th className="text-right">Produced</th>
                <th className="text-right">Target</th>
                <th className="text-right">Achievement</th>
              </tr>
            </thead>
            <tbody>
              {annual.map((a) => (
                <tr key={a.year} className="border-b last:border-0">
                  <td className="py-2 font-medium">{a.year}</td>
                  <td className="text-right">{a.produced.toFixed(3)}</td>
                  <td className="text-right">{a.target.toFixed(3)}</td>
                  <td className="text-right">
                    <span className={`font-semibold ${a.produced / a.target < 0.9 ? "text-red-600" : a.produced / a.target < 1 ? "text-amber-600" : "text-emerald-600"}`}>
                      {Math.round((a.produced / a.target) * 100)}%
                    </span>
                  </td>
                </tr>
              ))}
              <tr className="bg-orange-50">
                <td className="py-2 font-bold">Next 12 mo (AI)</td>
                <td className="text-right font-bold">{fc.forecastTotalMt.toFixed(3)}</td>
                <td className="text-right">{fc.targetTotalMt.toFixed(3)}</td>
                <td className="text-right font-bold text-orange-600">{Math.round((fc.forecastTotalMt / fc.targetTotalMt) * 100)}%</td>
              </tr>
            </tbody>
          </table>
          <p className="text-xs text-slate-500 mt-3">
            Prototype uses seasonal linear regression; the interface is designed so it can be swapped for a time-series model (Prophet / LSTM) without UI changes.
          </p>
        </Card>
      </div>
    </>
  );
}
