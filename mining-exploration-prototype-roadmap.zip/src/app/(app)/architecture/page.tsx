import { Card, PageHeader } from "@/components/ui";

const LAYERS = [
  {
    title: "1 · Data Sources",
    color: "bg-slate-700",
    items: ["Drill-hole logs (mines.csv, drillholes.csv)", "Production & equipment logs", "Sentinel-2 / Landsat-8 imagery", "Rainfall / environmental feeds", "MOIL ERP (future)"],
  },
  {
    title: "2 · Ingestion & Feature Store",
    color: "bg-sky-700",
    items: ["Cloud masking & zonal statistics", "Spectral indices (NDVI, iron-oxide, clay, bare-soil)", "Geochemistry normalisation", "PostgreSQL feature tables"],
  },
  {
    title: "3 · AI / ML Layer",
    color: "bg-orange-600",
    items: ["Random Forest → zone grade & reserve", "Seasonal regression → 12-mo production", "Composite risk scoring", "Rule-based recommendation engine"],
  },
  {
    title: "4 · API",
    color: "bg-emerald-700",
    items: ["/api/predict — live inference", "/api/select-mine, /api/auth", "Server-rendered analytics", "(FastAPI drop-in compatible)"],
  },
  {
    title: "5 · Decision UI",
    color: "bg-[#0b1f3a]",
    items: ["Dashboard KPIs", "Leaflet potential map", "Drill-hole & forecast charts", "Risk & recommendation screens", "Reports"],
  },
];

export default function ArchitecturePage() {
  return (
    <>
      <PageHeader step="System" title="Solution Architecture" description="From scattered geological, satellite, environmental and operational data to a single decision-support workflow: predict → detect risk → recommend action." />
      <div className="grid md:grid-cols-5 gap-3">
        {LAYERS.map((l, i) => (
          <div key={l.title} className="relative">
            <div className={`${l.color} text-white rounded-t-xl px-3 py-2 text-sm font-bold`}>{l.title}</div>
            <ul className="bg-white text-slate-900 border border-t-0 border-slate-200 rounded-b-xl p-3 space-y-2 text-xs min-h-[200px]">
              {l.items.map((it) => (
                <li key={it} className="flex gap-2">
                  <span className="text-orange-500">▸</span>
                  {it}
                </li>
              ))}
            </ul>
            {i < LAYERS.length - 1 && <div className="hidden md:block absolute top-1/2 -right-3 text-slate-400 text-xl z-10">→</div>}
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card title="Decision workflow" subtitle="Same flow as the app navigation">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
            {["Login", "Dashboard", "Select Mine", "Potential Map", "Drill-hole Analysis", "Production Forecast", "Risk", "AI Recommendation"].map((s, i, arr) => (
              <span key={s} className="flex items-center gap-2">
                <span className="rounded-full bg-amber-500 text-[#0b1526] px-3 py-1">{s}</span>
                {i < arr.length - 1 && <span className="text-slate-400">→</span>}
              </span>
            ))}
          </div>
        </Card>
        <Card title="Prototype → Production roadmap" subtitle="What changes as real data arrives">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-slate-500 border-b">
                <th className="py-1">Component</th>
                <th>Prototype</th>
                <th>Production</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Data", "Synthetic CSV/JSON in PostgreSQL", "MOIL drill DB, ERP, GSI datasets"],
                ["Satellite", "Pre-computed indices", "Copernicus/USGS API pipeline"],
                ["Reserve model", "Random Forest (7 features)", "RF + kriging / 3-D block model"],
                ["Forecast", "Seasonal linear regression", "Prophet / LSTM with weather covariates"],
                ["Recommendations", "Rule engine", "Rules + optimisation + LLM narrative"],
                ["Auth", "Demo accounts", "MOIL SSO / RBAC"],
              ].map(([a, b, c]) => (
                <tr key={a} className="border-b last:border-0">
                  <td className="py-1.5 font-semibold">{a}</td>
                  <td className="text-slate-600">{b}</td>
                  <td className="text-slate-600">{c}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}
