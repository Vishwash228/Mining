import { getEquipment } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, Kpi, PageHeader } from "@/components/ui";

const STATUS: Record<string, string> = {
  Healthy: "bg-emerald-100 text-emerald-800 border-emerald-200",
  Warning: "bg-amber-100 text-amber-800 border-amber-200",
  Critical: "bg-red-100 text-red-800 border-red-200",
  Maintenance: "bg-sky-100 text-sky-800 border-sky-200",
};

export default async function EquipmentPage() {
  const mine = await getSelectedMine();
  const fleet = await getEquipment(mine.id);
  const healthy = fleet.filter((e) => e.status === "Healthy").length;
  const critical = fleet.filter((e) => e.status === "Critical");
  const warning = fleet.filter((e) => e.status === "Warning");
  const avg = Math.round(fleet.reduce((a, e) => a + e.healthScore, 0) / fleet.length);
  const types = Array.from(new Set(fleet.map((e) => e.type)));

  return (
    <>
      <PageHeader step="Equipment Intelligence" title={`${mine.name} — Fleet Health`} description="Live telemetry (vibration, temperature, runtime) scored into a machine-health index with anomaly flags feeding the production forecast." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi label="Fleet health" value={avg} unit="%" hint={`${healthy} / ${fleet.length} healthy`} tone={avg >= 85 ? "good" : "warn"} />
        <Kpi label="Critical" value={critical.length} hint={critical.map((e) => e.code).join(", ") || "none"} tone={critical.length ? "bad" : "good"} />
        <Kpi label="Warnings" value={warning.length} hint={warning.map((e) => e.code).join(", ") || "none"} tone={warning.length ? "warn" : "good"} />
        <Kpi label="In maintenance" value={fleet.filter((e) => e.status === "Maintenance").length} hint="Planned service" />
      </div>

      <div id="anomaly" className="grid lg:grid-cols-3 gap-4 mt-4">
        {critical.concat(warning).map((e) => (
          <div key={e.id} className={`rounded-xl border p-4 bg-white text-slate-900 ${e.status === "Critical" ? "border-red-300" : "border-amber-300"}`}>
            <div className="flex items-center justify-between">
              <div className="font-bold">{e.name}</div>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${STATUS[e.status]}`}>{e.status}</span>
            </div>
            <p className="text-xs text-slate-600 mt-1">{e.note}</p>
            <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
              <div className="rounded bg-slate-50 p-2"><div className="text-slate-500">Vibration</div><div className={`font-bold ${e.vibrationMmS > 7 ? "text-red-600" : e.vibrationMmS > 4.5 ? "text-amber-600" : ""}`}>{e.vibrationMmS} mm/s</div></div>
              <div className="rounded bg-slate-50 p-2"><div className="text-slate-500">Temp</div><div className={`font-bold ${e.temperatureC > 90 ? "text-red-600" : ""}`}>{e.temperatureC} °C</div></div>
              <div className="rounded bg-slate-50 p-2"><div className="text-slate-500">Health</div><div className="font-bold">{e.healthScore}%</div></div>
            </div>
            <div className="mt-3 text-xs font-semibold text-amber-700">Action: {e.status === "Critical" ? "Stop & inspect bearings within 4 h; swap with standby unit." : "Schedule inspection at next shift change."}</div>
          </div>
        ))}
      </div>

      <Card title="Live monitoring — fleet" subtitle="ISO 10816 vibration bands · 22 machines" className="mt-4 text-slate-900">
        <div id="live" className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 xl:grid-cols-11 gap-2 mb-4">
          {fleet.map((e) => (
            <div key={e.id} title={`${e.name} · ${e.healthScore}%`} className={`rounded-lg p-2 text-center border ${STATUS[e.status]}`}>
              <div className="text-xs font-bold">{e.code}</div>
              <div className="text-[10px]">{e.healthScore}%</div>
            </div>
          ))}
        </div>
        <div id="health" className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left uppercase text-slate-500 border-b">
                <th className="py-2">Machine</th><th>Type</th><th>Status</th><th className="text-right">Health</th><th className="text-right">Vibration</th><th className="text-right">Temp</th><th className="text-right">Runtime h</th><th className="text-right">Last service</th>
              </tr>
            </thead>
            <tbody>
              {fleet.map((e) => (
                <tr key={e.id} className="border-b last:border-0 hover:bg-slate-50">
                  <td className="py-1.5 font-semibold">{e.name}</td>
                  <td>{e.type}</td>
                  <td><span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${STATUS[e.status]}`}>{e.status}</span></td>
                  <td className="text-right">
                    <span className="inline-block w-16 h-1.5 rounded-full bg-slate-100 align-middle mr-2 overflow-hidden"><span className={`block h-full ${e.healthScore >= 85 ? "bg-emerald-500" : e.healthScore >= 70 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${e.healthScore}%` }} /></span>{e.healthScore}%
                  </td>
                  <td className="text-right">{e.vibrationMmS}</td>
                  <td className="text-right">{e.temperatureC}</td>
                  <td className="text-right">{e.runtimeHours.toLocaleString()}</td>
                  <td className="text-right">{e.lastServiceDays} d ago</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 text-xs text-slate-500">Fleet composition: {types.map((t) => `${t} (${fleet.filter((e) => e.type === t).length})`).join(" · ")}</div>
      </Card>
    </>
  );
}
