import { assessRisk, getOverview } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, NextStep, PageHeader, RiskBadge, riskColor } from "@/components/ui";
import { RiskGauge, RiskComponentBars } from "@/components/charts/RiskCharts";

export default async function RiskPage() {
  const mine = await getSelectedMine();
  const [risk, overview] = await Promise.all([assessRisk(mine.id), getOverview()]);
  const f = risk.factors;

  const factorRows = [
    { name: "Production shortfall", value: `${f.shortfallPct}%`, threshold: "> 10% high", bad: f.shortfallPct > 10 },
    { name: "Grade decline (5 yr)", value: `${f.gradeDeclinePct}%`, threshold: "> 3% high", bad: f.gradeDeclinePct > 3 },
    { name: "Equipment uptime", value: `${f.uptimePct}%`, threshold: "< 85% high", bad: f.uptimePct < 85 },
    { name: "Reserve life at forecast rate", value: `${f.reserveLifeYears} yrs`, threshold: "< 8 yrs high", bad: f.reserveLifeYears < 8 },
    { name: "Monsoon production drop", value: `${Math.round(f.monsoonExposure * 100)}%`, threshold: "> 15% high", bad: f.monsoonExposure > 0.15 },
    { name: "Vegetation / land change (ΔNDVI)", value: `${f.vegetationEncroachment}`, threshold: "> 0.10 high", bad: f.vegetationEncroachment > 0.1 },
  ];

  return (
    <>
      <PageHeader
        step="Step 6 · Risk Detection"
        title={`${mine.name} — Risk Assessment`}
        description="Composite risk score (0–100) combining production shortfall, grade decline, downtime, reserve depletion, monsoon exposure and satellite-detected land change. Classified Low / Medium / High / Critical."
      >
        <NextStep href="/recommendations" label="AI recommendation" />
      </PageHeader>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card title="Overall risk score" subtitle="Weighted composite">
          <RiskGauge score={risk.score} color={riskColor(risk.level)} />
          <div className="text-center -mt-2">
            <RiskBadge level={risk.level} />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-1 text-[10px] text-center">
            {(["Low", "Medium", "High", "Critical"] as const).map((l) => (
              <div key={l} className={`rounded py-1 ${risk.level === l ? "text-white font-bold" : "bg-slate-100 text-slate-500"}`} style={risk.level === l ? { background: riskColor(l) } : {}}>
                {l}
                <div className="opacity-70">{l === "Low" ? "0–24" : l === "Medium" ? "25–49" : l === "High" ? "50–74" : "75+"}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card title="Risk drivers" subtitle="Contribution to score (grey = max possible)" className="lg:col-span-2">
          <RiskComponentBars data={risk.components.map((c) => ({ name: c.name, contribution: c.contribution, max: Math.round(c.weight * 100) }))} />
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card title="Factor detail" subtitle="Values computed from production, drill and satellite data">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-slate-500 border-b">
                <th className="py-1">Factor</th>
                <th className="text-right">Value</th>
                <th className="text-right">Threshold</th>
                <th className="text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {factorRows.map((r) => (
                <tr key={r.name} className="border-b last:border-0">
                  <td className="py-2">{r.name}</td>
                  <td className="text-right font-semibold">{r.value}</td>
                  <td className="text-right text-xs text-slate-500">{r.threshold}</td>
                  <td className="text-right">
                    <span className={`inline-block h-2.5 w-2.5 rounded-full ${r.bad ? "bg-red-500" : "bg-emerald-500"}`} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 rounded-lg bg-slate-50 p-3 text-xs text-slate-600 font-mono">
            risk = 0.35·shortfall + 0.20·grade_decline + 0.15·downtime + 0.15·reserve_depletion + 0.10·monsoon + 0.05·land_change
          </div>
        </Card>
        <Card title="Risk dashboard — all mines" subtitle="Company-level comparison">
          <div className="space-y-3">
            {overview.perMine.map((p) => (
              <div key={p.mine.id} className={`rounded-lg border p-3 text-slate-900 ${p.mine.id === mine.id ? "border-orange-400 bg-orange-50/40" : "border-slate-200"}`}>
                <div className="flex items-center justify-between text-sm">
                  <div className="font-semibold">{p.mine.name}</div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{p.risk.score}</span>
                    <RiskBadge level={p.risk.level} />
                  </div>
                </div>
                <div className="mt-2 h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div className="h-full" style={{ width: `${p.risk.score}%`, background: riskColor(p.risk.level) }} />
                </div>
                <div className="mt-1 text-[11px] text-slate-500">
                  Shortfall {p.forecast.shortfallPct}% · uptime {p.risk.factors.uptimePct}% · reserve life {p.risk.factors.reserveLifeYears} yrs
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}
