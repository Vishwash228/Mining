import { getSatellite } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { Card, PageHeader } from "@/components/ui";
import { SatelliteChart } from "@/components/charts/SatelliteChart";

export default async function SatellitePage() {
  const mine = await getSelectedMine();
  const sat = await getSatellite(mine.id);
  return (
    <>
      <PageHeader
        step="Space Technology · Satellite Data"
        title={`${mine.name} — Satellite-derived features`}
        description="Sentinel-2 MSI and Landsat-8 OLI scenes are reduced to spectral indices per lease area; these become model features alongside drill-hole geochemistry."
      />
      <div className="grid lg:grid-cols-3 gap-4">
        <Card title="Index time series" subtitle="Quarterly composites, 2021–2025" className="lg:col-span-2">
          <SatelliteChart data={sat.map((s) => ({ date: s.captureDate.slice(0, 7), ndvi: s.ndvi, ironOxide: s.ironOxideIndex, clay: s.clayIndex, bareSoil: s.bareSoilIndex }))} />
        </Card>
        <Card title="How indices are derived" subtitle="Band-ratio formulas">
          <ul className="text-xs space-y-2">
            <li className="rounded-lg bg-slate-50 p-2"><b>NDVI</b> = (NIR − Red) / (NIR + Red) — vegetation cover, reclamation & encroachment</li>
            <li className="rounded-lg bg-slate-50 p-2"><b>Iron-oxide index</b> = Red / Blue (B4/B2) — ferruginous alteration associated with Mn-oxide ores</li>
            <li className="rounded-lg bg-slate-50 p-2"><b>Clay index</b> = SWIR1 / SWIR2 (B11/B12) — hydrothermal / weathering clays</li>
            <li className="rounded-lg bg-slate-50 p-2"><b>Bare-soil index</b> = ((SWIR+Red) − (NIR+Blue)) / ((SWIR+Red)+(NIR+Blue)) — pit expansion & dumps</li>
            <li className="rounded-lg bg-slate-50 p-2"><b>LST</b> from thermal band — heat anomalies, waste-dump monitoring</li>
          </ul>
          <p className="mt-3 text-xs text-slate-500">Prototype: indices are pre-computed sample values. Production path: Copernicus / USGS API → cloud masking → zonal statistics → feature store.</p>
        </Card>
      </div>
      <Card title="satellite_features.csv" subtitle="Prototype sample rows" className="mt-4">
        <div className="overflow-auto max-h-96">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-white">
              <tr className="text-left uppercase text-slate-500 border-b">
                <th className="py-2">Date</th>
                <th>Sensor</th>
                <th className="text-right">NDVI</th>
                <th className="text-right">Iron-oxide</th>
                <th className="text-right">Clay</th>
                <th className="text-right">Bare soil</th>
                <th className="text-right">LST °C</th>
                <th className="text-right">Cloud %</th>
              </tr>
            </thead>
            <tbody>
              {sat.map((s) => (
                <tr key={s.id} className="border-b last:border-0">
                  <td className="py-1.5">{s.captureDate}</td>
                  <td>{s.sensor}</td>
                  <td className="text-right">{s.ndvi}</td>
                  <td className="text-right">{s.ironOxideIndex}</td>
                  <td className="text-right">{s.clayIndex}</td>
                  <td className="text-right">{s.bareSoilIndex}</td>
                  <td className="text-right">{s.landSurfaceTempC}</td>
                  <td className={`text-right ${s.cloudCoverPct > 40 ? "text-red-600" : ""}`}>{s.cloudCoverPct}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
