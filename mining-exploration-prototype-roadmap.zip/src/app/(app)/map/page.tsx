import { predictZones } from "@/lib/analytics";
import { getSelectedMine } from "@/lib/session";
import { NextStep, PageHeader } from "@/components/ui";
import MapClient from "@/components/map/MapClient";

export default async function MapPage({ searchParams }: { searchParams: Promise<{ zone?: string }> }) {
  const [{ zone }, mine] = await Promise.all([searchParams, getSelectedMine()]);
  const preds = await predictZones(mine.id);
  const best = [...preds].sort((a, b) => b.zone.probability - a.zone.probability)[0];
  const zones = preds.map((p) => ({
    id: p.zone.id,
    code: p.zone.code,
    name: p.zone.name,
    potential: p.zone.potential,
    probability: p.zone.probability,
    estReserveMt: p.zone.estReserveMt,
    predictedReserveMt: p.predictedReserveMt,
    predictedGradePct: p.predictedGradePct,
    gradeStd: p.gradeStd,
    confidence: p.confidence,
    areaHa: p.zone.areaHa,
    ndvi: p.zone.ndvi,
    ironOxideIndex: p.zone.ironOxideIndex,
    clayIndex: p.zone.clayIndex,
    polygon: JSON.parse(p.zone.polygon) as [number, number][],
    notes: p.zone.notes,
    holes: p.holes.map((h) => ({ holeId: h.holeId, lat: h.lat, lng: h.lng, mnPct: h.mnPct, depthM: h.depthM, thicknessM: h.thicknessM })),
  }));

  return (
    <>
      <PageHeader
        step="Step 3 · Manganese Potential Map"
        title={`${mine.name} — Potential Map`}
        description={`Zones coloured by AI-estimated manganese probability (drill-hole grades + satellite indices). Highest-potential zone: ${best.zone.code} (${Math.round(best.zone.probability * 100)}%). Click a zone for details.`}
      >
        <NextStep href="/drillholes" label="Drill-hole analysis" />
      </PageHeader>
      <MapClient center={[mine.lat, mine.lng]} mineName={mine.name} zones={zones} initialZoneCode={zone} />
    </>
  );
}
