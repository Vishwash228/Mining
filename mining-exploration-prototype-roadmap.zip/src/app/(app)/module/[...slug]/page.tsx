import { Card, PageHeader } from "@/components/ui";
import { getSelectedMine } from "@/lib/session";
import { getSatellite, getProduction, getEquipment, getReserveModel } from "@/lib/analytics";

type Meta = { title: string; group: string; desc: string; links: [string, string][] };
const META: Record<string, Meta> = {
  "reserve/3d-model": { title: "3D Block Model", group: "Reserve Intelligence", desc: "Voxelised grade model built from drill-hole intercepts (kriging). Prototype shows zone-level outputs; full 3-D viewer is on the roadmap.", links: [["/map", "Kriging Map"], ["/drillholes", "Drill Holes"]] },
  "reserve/resource-estimate": { title: "Resource Estimate", group: "Reserve Intelligence", desc: "Tonnage × grade summary per zone with confidence classes (Inferred / Indicated).", links: [["/drillholes", "Model outputs"], ["/reports", "Report"]] },
  "satellite/ndwi": { title: "NDWI — Water Index", group: "Satellite Intelligence", desc: "Normalised Difference Water Index for pit-water and flooding monitoring.", links: [["/satellite", "Satellite overview"]] },
  "satellite/lst": { title: "LST — Land Surface Temperature", group: "Satellite Intelligence", desc: "Thermal-band surface temperature for dump heating and heat-stress alerts.", links: [["/satellite", "Satellite overview"]] },
  "satellite/rainfall": { title: "Rainfall", group: "Satellite Intelligence", desc: "IMD / GPM rainfall feeds correlated with production dips.", links: [["/forecast", "Forecast"], ["/risk", "Risk"]] },
  "satellite/soil-moisture": { title: "Soil Moisture", group: "Satellite Intelligence", desc: "SMAP / Sentinel-1 derived soil moisture for haul-road trafficability.", links: [["/satellite", "Satellite overview"]] },
  "satellite/terrain": { title: "Terrain", group: "Satellite Intelligence", desc: "DEM-derived slope and bench geometry.", links: [["/map", "Map"]] },
  "satellite/change-detection": { title: "Change Detection", group: "Satellite Intelligence", desc: "Multi-temporal pit expansion, dump growth and green-belt change.", links: [["/satellite", "Satellite overview"]] },
  "production/factors": { title: "Production Factors", group: "Production Intelligence", desc: "Driver decomposition: equipment uptime, rainfall, grade, blasting schedule.", links: [["/risk", "Risk drivers"]] },
  "production/what-if": { title: "What-If Analysis", group: "Production Intelligence", desc: "Scenario simulation — change uptime / rainfall / zone mix and see forecast impact.", links: [["/drillholes", "Model playground"]] },
  "equipment/maintenance": { title: "Maintenance", group: "Equipment Intelligence", desc: "Preventive-maintenance schedule driven by health scores.", links: [["/equipment", "Fleet health"]] },
  "equipment/downtime": { title: "Downtime", group: "Equipment Intelligence", desc: "Downtime log and Pareto of causes.", links: [["/equipment", "Fleet health"]] },
  "ai-model-center": { title: "AI Model Center", group: "System", desc: "Model registry, training metrics and feature importances.", links: [["/drillholes", "Reserve model"], ["/api/predict", "Predict API"]] },
  analytics: { title: "Analytics", group: "System", desc: "Cross-mine analytics workspace.", links: [["/dashboard", "Dashboard"]] },
  "data-upload": { title: "Data Upload", group: "System", desc: "Upload drillholes.csv / production.csv / satellite_features.csv (prototype: seeded automatically).", links: [["/architecture", "Data sources"]] },
  settings: { title: "Settings", group: "System", desc: "Users, roles, thresholds and notification preferences.", links: [["/dashboard", "Dashboard"]] },
};

export default async function ModulePage({ params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params;
  const key = slug.join("/");
  const meta: Meta = META[key] ?? { title: slug[slug.length - 1].replace(/-/g, " "), group: "Module", desc: "Module placeholder.", links: [["/dashboard", "Dashboard"]] };
  const mine = await getSelectedMine();
  const [sat, prod, fleet, model] = await Promise.all([getSatellite(mine.id), getProduction(mine.id), getEquipment(mine.id), getReserveModel()]);
  const last = sat[sat.length - 1];
  const lastProd = prod[prod.length - 1];

  return (
    <>
      <PageHeader step={meta.group} title={meta.title} description={meta.desc} />
      <div className="grid lg:grid-cols-3 gap-4 text-slate-900">
        <Card title="Latest data snapshot" subtitle={mine.name}>
          <dl className="text-sm space-y-2">
            <Row k="Satellite scene" v={`${last.captureDate} · ${last.sensor}`} />
            <Row k="NDVI / LST" v={`${last.ndvi} / ${last.landSurfaceTempC} °C`} />
            <Row k="Last month rainfall" v={`${lastProd.rainfallMm} mm`} />
            <Row k="Equipment uptime" v={`${lastProd.equipmentUptimePct}%`} />
            <Row k="Fleet size" v={`${fleet.length} machines`} />
            <Row k="Reserve model" v={`Random Forest · R² ${model.r2.toFixed(2)}`} />
          </dl>
        </Card>
        <Card title="Status" subtitle="Prototype scope" className="lg:col-span-2">
          <div className="rounded-lg border border-dashed border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
            This module is wired into the navigation and data layer; the dedicated visualisation is scheduled for the next sprint. The underlying data is already available via the linked screens below.
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {meta.links.map(([href, label]) => (
              <a key={href} href={href} className="rounded-lg bg-[#0b1526] text-white px-3 py-1.5 text-xs font-semibold hover:bg-[#1a2c48]">{label} →</a>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between border-b last:border-0 pb-1"><dt className="text-slate-500">{k}</dt><dd className="font-semibold">{v}</dd></div>;
}
