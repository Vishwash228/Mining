import { NextResponse } from "next/server";
import { MINE_COOKIE } from "@/lib/session";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id") ?? "";
  const next = url.searchParams.get("next") ?? "/map";
  const res = NextResponse.redirect(new URL(next.startsWith("/") ? next : "/map", req.url));
  res.cookies.set(MINE_COOKIE, id, { path: "/", sameSite: "lax", maxAge: 60 * 60 * 24 * 30 });
  return res;
}
