import { NextResponse } from "next/server";
import { getReserveModel, RESERVE_FEATURES } from "@/lib/analytics";

/**
 * ML inference endpoint (prototype).
 * POST { depth, thickness, fe, sio2, ndvi, ironOxide, clay, areaHa?, probability? }
 * → predicted Mn grade + reserve estimate from the Random Forest model.
 */
export async function POST(req: Request) {
  const b = await req.json();
  const { model, r2, n } = await getReserveModel();
  const x = [
    Number(b.depth ?? 120),
    Number(b.thickness ?? 4),
    Number(b.fe ?? 10),
    Number(b.sio2 ?? 15),
    Number(b.ndvi ?? 0.3),
    Number(b.ironOxide ?? 1.8),
    Number(b.clay ?? 1.6),
  ];
  const { mean, std } = model.predictWithSpread(x);
  const areaHa = Number(b.areaHa ?? 40);
  const probability = Number(b.probability ?? 0.7);
  const reserveMt = (areaHa * 10000 * x[1] * 3.4 * probability) / 1e6;
  return NextResponse.json({
    model: "RandomForestRegressor(n_estimators=40, max_depth=5)",
    trainingSamples: n,
    r2: +r2.toFixed(3),
    predictedGradeMnPct: +mean.toFixed(2),
    gradeStd: +std.toFixed(2),
    predictedReserveMt: +reserveMt.toFixed(2),
    featureImportances: RESERVE_FEATURES.map((f, i) => ({ feature: f, importance: +model.featureImportances()[i].toFixed(3) })),
  });
}

export async function GET() {
  const { model, r2, n } = await getReserveModel();
  return NextResponse.json({
    model: "RandomForestRegressor(n_estimators=40, max_depth=5)",
    trainingSamples: n,
    r2: +r2.toFixed(3),
    featureImportances: RESERVE_FEATURES.map((f, i) => ({ feature: f, importance: +model.featureImportances()[i].toFixed(3) })),
  });
}
