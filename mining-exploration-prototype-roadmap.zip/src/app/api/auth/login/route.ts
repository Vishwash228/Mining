import { NextResponse } from "next/server";
import { DEMO_USERS, SESSION_COOKIE } from "@/lib/session";

export async function POST(req: Request) {
  const { username, password } = await req.json();
  const user = DEMO_USERS[String(username ?? "").toLowerCase()];
  if (!user || user.password !== password) {
    return NextResponse.json({ error: "Invalid credentials. Try manager / vision123" }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true, name: user.name });
  res.cookies.set(SESSION_COOKIE, `${String(username).toLowerCase()}:${Date.now()}`, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
  });
  return res;
}
