"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

const ROLES = [
  { key: "manager", label: "Mine Manager" },
  { key: "geologist", label: "Geologist" },
  { key: "production", label: "Production Manager" },
  { key: "maintenance", label: "Maintenance Engineer" },
  { key: "admin", label: "Administrator" },
];

type Phase = "idle" | "press" | "impact" | "zoom";

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState("manager");
  const [username, setUsername] = useState("manager");
  const [password, setPassword] = useState("vision123");
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const btnRef = useRef<HTMLButtonElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Ambient drifting dust particles
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    let raf = 0;
    const resize = () => { c.width = window.innerWidth; c.height = window.innerHeight; };
    resize();
    window.addEventListener("resize", resize);
    const dust = Array.from({ length: 70 }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, r: 0.6 + Math.random() * 1.6, vx: 0.08 + Math.random() * 0.2, vy: -0.05 - Math.random() * 0.12, a: 0.15 + Math.random() * 0.35 }));
    type Burst = { x: number; y: number; vx: number; vy: number; r: number; life: number; color: string };
    let burst: Burst[] = [];
    let wave = -1;
    let origin = { x: 0, y: 0 };
    const spawnBurst = (x: number, y: number) => {
      origin = { x, y };
      wave = 0;
      burst = Array.from({ length: 140 }, () => {
        const ang = Math.random() * Math.PI * 2;
        const sp = 2 + Math.random() * 7;
        const rock = Math.random() < 0.35;
        return { x, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - 2, r: rock ? 1.5 + Math.random() * 2.5 : 3 + Math.random() * 9, life: 1, color: rock ? "#6b5b4a" : "#c9a27a" };
      });
    };
    (window as unknown as { __vcBurst?: (x: number, y: number) => void }).__vcBurst = spawnBurst;
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      for (const d of dust) {
        d.x += d.vx; d.y += d.vy;
        if (d.x > c.width) d.x = 0;
        if (d.y < 0) d.y = c.height;
        ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(230,200,160,${d.a})`; ctx.fill();
      }
      if (wave >= 0) {
        wave += 14;
        ctx.beginPath(); ctx.arc(origin.x, origin.y, wave, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(244,121,31,${Math.max(0, 0.7 - wave / 900)})`; ctx.lineWidth = 3; ctx.stroke();
        if (wave > 1200) wave = -1;
      }
      burst = burst.filter((p) => p.life > 0);
      for (const p of burst) {
        p.x += p.vx; p.y += p.vy; p.vy += 0.12; p.vx *= 0.985; p.life -= 0.016;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.5 + p.life), 0, Math.PI * 2);
        ctx.fillStyle = p.color + Math.round(p.life * 180).toString(16).padStart(2, "0"); ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  function thud() {
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ac = new AC();
      const o = ac.createOscillator(); const g = ac.createGain();
      o.type = "sine"; o.frequency.setValueAtTime(110, ac.currentTime); o.frequency.exponentialRampToValueAtTime(30, ac.currentTime + 0.35);
      g.gain.setValueAtTime(0.5, ac.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.45);
      o.connect(g).connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.5);
      // dust noise layer
      const buf = ac.createBuffer(1, ac.sampleRate * 0.3, ac.sampleRate); const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length) * 0.25;
      const n = ac.createBufferSource(); n.buffer = buf; const f = ac.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 500;
      n.connect(f).connect(ac.destination); n.start();
    } catch { /* audio not available */ }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (phase !== "idle") return;
    setError(null);
    setPhase("press");
    const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password }) });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error ?? "Login failed");
      setPhase("idle");
      return;
    }
    sessionStorage.setItem("vc_entry", "1");
    router.prefetch("/dashboard");
    const r = btnRef.current?.getBoundingClientRect();
    setTimeout(() => {
      setPhase("impact");
      thud();
      (window as unknown as { __vcBurst?: (x: number, y: number) => void }).__vcBurst?.(r ? r.left + r.width / 2 : innerWidth / 2, r ? r.top + r.height / 2 : innerHeight / 2);
    }, 180);
    setTimeout(() => setPhase("zoom"), 620);
    setTimeout(() => { router.push("/dashboard"); router.refresh(); }, 1100);
  }

  return (
    <main className={`relative min-h-screen overflow-hidden bg-[#0a1220] text-white ${phase === "impact" ? "vc-shake" : ""}`}>
      <div
        className={`absolute inset-0 bg-cover bg-center transition-transform duration-[900ms] ease-in ${phase === "zoom" ? "scale-[1.35] blur-sm" : "scale-100"}`}
        style={{ backgroundImage: "url(/images/mine-bg.jpg)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1220]/70 via-[#0a1220]/40 to-[#0a1220]/85" />
      <div className="absolute inset-0 vc-grid opacity-[0.12]" />
      <div className="absolute inset-0 vc-contours opacity-[0.10]" />
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />
      {phase === "impact" && <div className="absolute inset-0 bg-amber-200 vc-flash pointer-events-none" />}
      {phase === "zoom" && <div className="absolute inset-0 bg-[#0a1220] vc-fadein pointer-events-none" />}

      <div className={`relative z-10 min-h-screen flex flex-col items-center justify-center p-6 transition-all duration-700 ${phase === "zoom" ? "opacity-0 scale-110" : ""}`}>
        <div className="text-center mb-8">
          <div className="text-[11px] tracking-[0.35em] text-amber-400/90 font-semibold">AI + SPACE TECHNOLOGY</div>
          <h1 className="mt-2 text-5xl font-black tracking-[0.15em]">VISION CRAFT</h1>
          <div className="mt-1 text-sm text-slate-300 tracking-wider">Mining Intelligence Platform</div>
          <div className="mt-3 text-xs text-slate-400">Smart Mining Intelligence</div>
        </div>

        <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-white/15 bg-white/[0.07] backdrop-blur-xl shadow-2xl shadow-black/40 p-7 space-y-4">
          <label className="block">
            <span className="text-xs text-slate-300">Email / Username</span>
            <input className="mt-1 w-full rounded-lg bg-black/30 border border-white/15 px-3 py-2.5 text-sm outline-none focus:border-amber-400" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
          </label>
          <label className="block">
            <span className="text-xs text-slate-300">Password</span>
            <input type="password" className="mt-1 w-full rounded-lg bg-black/30 border border-white/15 px-3 py-2.5 text-sm outline-none focus:border-amber-400" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
          </label>
          <div className="flex items-center justify-between text-xs text-slate-300">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="accent-amber-500" /> Remember me
            </label>
            <button type="button" className="hover:text-white">Forgot Password?</button>
          </div>
          {error && <div className="text-xs text-red-200 bg-red-500/20 border border-red-400/30 rounded-lg p-2">{error}</div>}
          <button
            ref={btnRef}
            disabled={phase !== "idle"}
            className={`relative w-full rounded-lg bg-amber-500 text-[#0a1220] py-3 font-bold tracking-widest transition-transform duration-150 hover:bg-amber-400 disabled:opacity-90 ${phase === "press" ? "scale-95" : ""} ${phase !== "idle" ? "vc-pulse" : ""}`}
          >
            {phase === "idle" ? "LOGIN" : phase === "press" ? "AUTHENTICATING…" : "SYSTEM ONLINE"}
          </button>
          <div className="text-center text-[11px] text-slate-400">Demo Login • {ROLES.find((r) => r.key === role)?.label}</div>
          <div className="pt-1">
            <div className="text-[10px] text-slate-400 mb-1.5">Role</div>
            <div className="flex flex-wrap gap-1.5">
              {ROLES.map((r) => (
                <button
                  key={r.key}
                  type="button"
                  onClick={() => { setRole(r.key); setUsername(r.key); setPassword("vision123"); }}
                  className={`text-[10px] px-2 py-1 rounded-md border transition ${role === r.key ? "bg-amber-500/20 border-amber-400 text-amber-200" : "border-white/15 text-slate-300 hover:border-white/40"}`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </form>
        <div className="mt-6 text-[10px] text-slate-500">Prototype · demo data · password for all roles: vision123</div>
      </div>
    </main>
  );
}
