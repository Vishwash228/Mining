"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function HeaderBar({ mines, selectedId, user, alerts }: { mines: { id: number; name: string; code: string }[]; selectedId: number; user: { name: string; role: string }; alerts: number }) {
  const path = usePathname();
  const router = useRouter();
  const [now, setNow] = useState<Date | null>(null);
  const [spin, setSpin] = useState(false);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  const date = now ? now.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "—";
  const time = now ? now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }) : "—";

  return (
    <header className="vc-header no-print sticky top-0 z-20 bg-[#0f1b2d]/90 backdrop-blur border-b border-white/10 px-6 py-3 flex items-center gap-6 text-white">
      <label className="flex items-center gap-2 text-xs text-slate-400">
        <span>Mine:</span>
        <select
          className="rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-sm font-semibold text-white"
          value={selectedId}
          onChange={(e) => (window.location.href = `/api/select-mine?id=${e.target.value}&next=${encodeURIComponent(path)}`)}
        >
          {mines.map((m) => (
            <option key={m.id} value={m.id} className="text-slate-900">
              {m.code} · {m.name.split(" — ")[1]}
            </option>
          ))}
        </select>
      </label>
      <div className="text-xs text-slate-400 hidden md:block">
        Date: <span className="text-white font-medium">{date}</span>
      </div>
      <div className="text-xs text-slate-400 hidden md:flex items-center gap-2">
        Last Updated: <span className="text-white font-medium">{time}</span>
        <span className="flex items-center gap-1 text-emerald-300 font-semibold">
          <span className="relative h-2 w-2"><span className="absolute inset-0 rounded-full bg-emerald-400 vc-ping" /><span className="absolute inset-0 rounded-full bg-emerald-400" /></span> LIVE
        </span>
      </div>
      <div className="ml-auto flex items-center gap-4">
        <button
          onClick={() => { setSpin(true); router.refresh(); setTimeout(() => setSpin(false), 800); }}
          className="text-xs text-slate-300 hover:text-white flex items-center gap-1"
          title="Refresh"
        >
          <span className={`inline-block ${spin ? "animate-spin" : ""}`}>⟳</span> Refresh
        </button>
        <a href="/recommendations" className="relative text-slate-300 hover:text-white" title="Notifications">
          <span className="text-lg">🔔</span>
          {alerts > 0 && (
            <span className="absolute -top-1 -right-1 h-4 min-w-4 px-1 rounded-full bg-red-500 text-[10px] font-bold grid place-items-center">
              {alerts}
              <span className="absolute inset-0 rounded-full bg-red-500 vc-ping -z-10" />
            </span>
          )}
        </a>
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-600 grid place-items-center text-xs font-bold text-[#0b1526]">
            {user.name.split(" ").map((s) => s[0]).slice(0, 2).join("")}
          </div>
          <div className="leading-tight hidden sm:block">
            <div className="text-sm font-semibold">{user.name}</div>
            <div className="text-[11px] text-slate-400">{user.role}</div>
          </div>
        </div>
        <a href="/api/auth/logout" className="text-xs text-slate-400 hover:text-red-400">Logout</a>
      </div>
    </header>
  );
}
