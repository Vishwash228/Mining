"use client";

import { useEffect, useState } from "react";

const FIELDS: { key: string; label: string; min: number; max: number; step: number; def: number }[] = [
  { key: "depth", label: "Depth (m)", min: 20, max: 450, step: 5, def: 220 },
  { key: "thickness", label: "Seam thickness (m)", min: 0.5, max: 10, step: 0.1, def: 6 },
  { key: "fe", label: "Fe %", min: 3, max: 20, step: 0.1, def: 7 },
  { key: "sio2", label: "SiO₂ %", min: 5, max: 30, step: 0.5, def: 10 },
  { key: "ndvi", label: "NDVI (satellite)", min: 0.05, max: 0.7, step: 0.01, def: 0.2 },
  { key: "ironOxide", label: "Iron-oxide index", min: 0.8, max: 2.6, step: 0.01, def: 2.2 },
  { key: "clay", label: "Clay index", min: 0.9, max: 2.2, step: 0.01, def: 1.8 },
  { key: "areaHa", label: "Zone area (ha)", min: 10, max: 80, step: 1, def: 50 },
  { key: "probability", label: "Mn probability", min: 0.1, max: 0.99, step: 0.01, def: 0.9 },
];

type Result = { predictedGradeMnPct: number; gradeStd: number; predictedReserveMt: number; r2: number; trainingSamples: number };

export default function PredictPlayground() {
  const [vals, setVals] = useState<Record<string, number>>(Object.fromEntries(FIELDS.map((f) => [f.key, f.def])));
  const [res, setRes] = useState<Result | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      fetch("/api/predict", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(vals) })
        .then((r) => r.json())
        .then(setRes)
        .catch(() => setRes(null));
    }, 250);
    return () => clearTimeout(t);
  }, [vals]);

  return (
    <div className="grid sm:grid-cols-2 gap-4">
      <div className="space-y-2">
        {FIELDS.map((f) => (
          <label key={f.key} className="block text-xs">
            <div className="flex justify-between">
              <span className="text-slate-600">{f.label}</span>
              <span className="font-semibold">{vals[f.key]}</span>
            </div>
            <input type="range" min={f.min} max={f.max} step={f.step} value={vals[f.key]} onChange={(e) => setVals({ ...vals, [f.key]: Number(e.target.value) })} className="w-full accent-orange-500" />
          </label>
        ))}
      </div>
      <div className="rounded-xl bg-[#0b1f3a] text-white p-4 flex flex-col justify-center">
        <div className="text-[11px] text-slate-300 uppercase tracking-wide">Model output</div>
        {res ? (
          <>
            <div className="mt-2 text-3xl font-bold text-orange-400">
              {res.predictedGradeMnPct}% <span className="text-base text-slate-300">Mn</span>
            </div>
            <div className="text-xs text-slate-300">± {res.gradeStd} (tree spread)</div>
            <div className="mt-4 text-2xl font-bold">
              {res.predictedReserveMt} <span className="text-base text-slate-300">MT reserve</span>
            </div>
            <div className="mt-4 text-[11px] text-slate-400">
              RandomForestRegressor · {res.trainingSamples} samples · train R² {res.r2}
            </div>
          </>
        ) : (
          <div className="text-sm text-slate-300 mt-2">Running inference…</div>
        )}
      </div>
    </div>
  );
}
