"use client";

import dynamic from "next/dynamic";
import type { ComponentProps } from "react";
import type PotentialMapType from "./PotentialMap";

const PotentialMap = dynamic(() => import("./PotentialMap"), {
  ssr: false,
  loading: () => <div className="h-[560px] rounded-xl bg-slate-200 animate-pulse grid place-items-center text-slate-500 text-sm">Loading map…</div>,
});

export default function MapClient(props: ComponentProps<typeof PotentialMapType>) {
  return <PotentialMap {...props} />;
}
