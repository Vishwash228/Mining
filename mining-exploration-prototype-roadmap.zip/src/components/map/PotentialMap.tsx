"use client";

import { useMemo, useState } from "react";
import { MapContainer, TileLayer, Polygon, CircleMarker, Tooltip, LayersControl, LayerGroup } from "react-leaflet";
import { potentialColor, PotentialBadge } from "@/components/ui";

export type MapZone = {
  id: number;
  code: string;
  name: string;
  potential: string;
  probability: number;
  estReserveMt: number;
  predictedReserveMt: number;
  predictedGradePct: number;
  gradeStd: number;
  confidence: number;
  areaHa: number;
  ndvi: number;
  ironOxideIndex: number;
  clayIndex: number;
  polygon: [number, number][];
  notes: string | null;
  holes: { holeId: string; lat: number; lng: number; mnPct: number; depthM: number; thicknessM: number }[];
};

export default function PotentialMap({ center, mineName, zones, initialZoneCode, compact }: { center: [number, number]; mineName: string; zones: MapZone[]; initialZoneCode?: string; compact?: boolean }) {
  const [selectedId, setSelectedId] = useState<number | null>(zones.find((z) => z.code === initialZoneCode)?.id ?? null);
  const selected = useMemo(() => zones.find((z) => z.id === selectedId) ?? null, [zones, selectedId]);

  return (
    <div className={compact ? "" : "grid lg:grid-cols-3 gap-4"}>
      <div className="lg:col-span-2 rounded-xl overflow-hidden border border-slate-200 shadow-sm relative" style={{ height: compact ? 380 : 560 }}>
        <MapContainer center={center} zoom={14} style={{ height: "100%", width: "100%" }} scrollWheelZoom>
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="OpenStreetMap">
              <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
            </LayersControl.BaseLayer>
            <LayersControl.BaseLayer name="Satellite (Esri World Imagery)">
              <TileLayer
                attribution="Tiles &copy; Esri — Source: Esri, Maxar, Earthstar Geographics"
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              />
            </LayersControl.BaseLayer>
            <LayersControl.Overlay checked name="Manganese potential zones">
              <LayerGroup>
                {zones.map((z) => {
                  const color = potentialColor[z.potential];
                  const isSel = z.id === selectedId;
                  return (
                    <Polygon
                      key={z.id}
                      positions={z.polygon}
                      pathOptions={{ color: isSel ? "#0b1f3a" : color, fillColor: color, fillOpacity: isSel ? 0.65 : 0.4, weight: isSel ? 3 : 1.5 }}
                      eventHandlers={{ click: () => setSelectedId(z.id) }}
                    >
                      <Tooltip sticky>
                        <b>Zone {z.code}</b> · {z.name}
                        <br />
                        {z.potential} potential · {Math.round(z.probability * 100)}%
                      </Tooltip>
                    </Polygon>
                  );
                })}
              </LayerGroup>
            </LayersControl.Overlay>
            <LayersControl.Overlay checked name="Drill holes">
              <LayerGroup>
                {zones.flatMap((z) =>
                  z.holes.map((h) => (
                    <CircleMarker key={h.holeId} center={[h.lat, h.lng]} radius={5} pathOptions={{ color: "#0b1f3a", fillColor: "#fff", fillOpacity: 1, weight: 2 }}>
                      <Tooltip>
                        <b>{h.holeId}</b>
                        <br />
                        Mn {h.mnPct}% · depth {h.depthM} m · thickness {h.thicknessM} m
                      </Tooltip>
                    </CircleMarker>
                  )),
                )}
              </LayerGroup>
            </LayersControl.Overlay>
          </LayersControl>
        </MapContainer>
        <div className="absolute bottom-3 left-3 z-[1000] bg-white/95 rounded-lg shadow px-3 py-2 text-xs space-y-1">
          <div className="font-semibold text-slate-700">Legend — Mn potential</div>
          {(["High", "Medium", "Low"] as const).map((l) => (
            <div key={l} className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm" style={{ background: potentialColor[l] }} /> {l} ({l === "High" ? "≥ 70%" : l === "Medium" ? "40–70%" : "< 40%"})
            </div>
          ))}
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full border-2 border-[#0b1f3a] bg-white" /> Drill hole
          </div>
        </div>
      </div>

      {!compact && <div className="space-y-3">
        {selected ? (
          <div className="bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm p-5">
            <div className="flex items-center justify-between">
              <div className="text-xs font-semibold text-slate-500">{mineName}</div>
              <PotentialBadge level={selected.potential} />
            </div>
            <h3 className="text-xl font-bold mt-1">
              Zone {selected.code} · {selected.name}
            </h3>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <Stat label="Mn probability" value={`${Math.round(selected.probability * 100)}%`} accent />
              <Stat label="Predicted reserve" value={`${selected.predictedReserveMt} MT`} />
              <Stat label="Predicted grade (RF)" value={`${selected.predictedGradePct}% ± ${selected.gradeStd}`} />
              <Stat label="Model confidence" value={`${selected.confidence}%`} />
              <Stat label="Area" value={`${selected.areaHa} ha`} />
              <Stat label="Drill holes" value={`${selected.holes.length}`} />
            </div>
            <div className="mt-4">
              <div className="text-xs font-semibold text-slate-500 mb-1">Satellite-derived features</div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <Mini label="NDVI" value={selected.ndvi} />
                <Mini label="Iron-oxide" value={selected.ironOxideIndex} />
                <Mini label="Clay idx" value={selected.clayIndex} />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-xs font-semibold text-slate-500 mb-1">Probability</div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full" style={{ width: `${selected.probability * 100}%`, background: potentialColor[selected.potential] }} />
              </div>
            </div>
            {selected.notes && <p className="mt-4 text-sm text-slate-600 bg-slate-50 rounded-lg p-3">{selected.notes}</p>}
            <div className="mt-4 text-xs text-slate-500">
              Intercepts: {selected.holes.map((h) => `${h.holeId} (${h.mnPct}%)`).join(", ") || "none"}
            </div>
            <a href={`/drillholes?zone=${selected.code}`} className="mt-4 inline-flex w-full justify-center rounded-lg bg-[#0b1f3a] text-white py-2 text-sm font-semibold hover:bg-[#153059]">
              Analyse drill holes in {selected.code} →
            </a>
          </div>
        ) : (
          <div className="bg-white/10 rounded-xl border border-dashed border-slate-500 p-6 text-center text-sm text-slate-300">
            Click a coloured zone on the map to see its AI potential assessment.
          </div>
        )}

        <div className="bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm p-4">
          <div className="text-xs font-semibold text-slate-500 mb-2">Zone ranking</div>
          <ul className="space-y-1">
            {[...zones]
              .sort((a, b) => b.probability - a.probability)
              .map((z) => (
                <li key={z.id}>
                  <button
                    onClick={() => setSelectedId(z.id)}
                    className={`w-full flex items-center justify-between text-sm rounded-lg px-2 py-1.5 hover:bg-slate-50 ${z.id === selectedId ? "bg-orange-50" : ""}`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: potentialColor[z.potential] }} />
                      <b>{z.code}</b> <span className="text-slate-500">{z.name}</span>
                    </span>
                    <span className="font-semibold">{Math.round(z.probability * 100)}%</span>
                  </button>
                </li>
              ))}
          </ul>
        </div>
      </div>}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-lg bg-slate-50 p-3">
      <div className="text-[11px] text-slate-500">{label}</div>
      <div className={`font-bold ${accent ? "text-orange-600 text-lg" : "text-slate-800"}`}>{value}</div>
    </div>
  );
}
function Mini({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded border border-slate-200 p-2 text-center">
      <div className="text-slate-500">{label}</div>
      <div className="font-semibold">{value.toFixed(2)}</div>
    </div>
  );
}
