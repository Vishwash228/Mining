"use client";

import { useEffect, useState, type ReactNode } from "react";

/** Applies the cinematic dashboard-entry animation once, right after login. */
export default function EntryShell({ children }: { children: ReactNode }) {
  const [entry, setEntry] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("vc_entry") === "1") {
      sessionStorage.removeItem("vc_entry");
      setEntry(true);
      const t = setTimeout(() => setEntry(false), 2500);
      return () => clearTimeout(t);
    }
  }, []);
  return <div className={`flex min-h-screen bg-[#0f1b2d] ${entry ? "vc-entry" : ""}`}>{children}</div>;
}
