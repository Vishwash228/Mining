"use client";

import { Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { ForecastPoint } from "@/lib/analytics";

export function ForecastChart({ points }: { points: ForecastPoint[] }) {
  const firstForecast = points.find((p) => p.actual === null)?.label;
  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={points} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={2} />
          <YAxis tick={{ fontSize: 11 }} unit=" kt" domain={["auto", "auto"]} />
          <Tooltip />
          <Legend />
          <Area type="monotone" dataKey="upper" stroke="none" fill="#f4791f" fillOpacity={0.12} name="90% band (upper)" legendType="none" />
          <Area type="monotone" dataKey="lower" stroke="none" fill="#ffffff" fillOpacity={1} name="90% band (lower)" legendType="none" />
          <Line type="monotone" dataKey="target" stroke="#64748b" strokeDasharray="6 4" dot={false} name="Monthly target" />
          <Line type="monotone" dataKey="actual" stroke="#0b1f3a" strokeWidth={2} dot={{ r: 2 }} name="Actual production" />
          <Line type="monotone" dataKey="forecast" stroke="#f4791f" strokeWidth={2.5} strokeDasharray="4 2" dot={{ r: 2 }} name="AI forecast" />
          {firstForecast && <ReferenceLine x={firstForecast} stroke="#f4791f" label={{ value: "forecast →", fontSize: 11, fill: "#f4791f", position: "top" }} />}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
