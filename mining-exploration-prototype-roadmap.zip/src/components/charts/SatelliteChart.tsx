"use client";

import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function SatelliteChart({ data }: { data: { date: string; ndvi: number; ironOxide: number; clay: number; bareSoil: number }[] }) {
  return (
    <div className="h-72">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={3} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="ndvi" name="NDVI" stroke="#16a34a" dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="ironOxide" name="Iron-oxide index" stroke="#b91c1c" dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="clay" name="Clay index" stroke="#f59e0b" dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="bareSoil" name="Bare-soil index" stroke="#64748b" dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
