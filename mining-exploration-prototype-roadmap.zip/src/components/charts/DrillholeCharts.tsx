"use client";

import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from "recharts";

export function GradeDepthScatter({ data }: { data: { holeId: string; depthM: number; mnPct: number; thicknessM: number; zone: string; color: string }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis type="number" dataKey="depthM" name="Depth" unit=" m" tick={{ fontSize: 11 }} />
          <YAxis type="number" dataKey="mnPct" name="Mn" unit="%" tick={{ fontSize: 11 }} domain={["auto", "auto"]} />
          <ZAxis type="number" dataKey="thicknessM" range={[40, 300]} name="Thickness" unit=" m" />
          <Tooltip
            cursor={{ strokeDasharray: "3 3" }}
            content={({ payload }) => {
              const p = payload?.[0]?.payload;
              if (!p) return null;
              return (
                <div className="bg-white border border-slate-200 rounded-lg shadow px-3 py-2 text-xs">
                  <b>{p.holeId}</b> · Zone {p.zone}
                  <br />Mn {p.mnPct}% · {p.depthM} m · thickness {p.thicknessM} m
                </div>
              );
            }}
          />
          <Scatter data={data}>
            {data.map((d) => (
              <Cell key={d.holeId} fill={d.color} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ZoneGradeBars({ data }: { data: { zone: string; measured: number; predicted: number; color: string }[] }) {
  return (
    <div className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="zone" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} unit="%" domain={[0, "auto"]} />
          <Tooltip />
          <Bar dataKey="measured" name="Measured avg Mn %" fill="#94a3b8" radius={[4, 4, 0, 0]} />
          <Bar dataKey="predicted" name="RF predicted Mn %" radius={[4, 4, 0, 0]}>
            {data.map((d) => (
              <Cell key={d.zone} fill={d.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ImportanceBars({ data }: { data: { feature: string; importance: number }[] }) {
  return (
    <div className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 40 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `${Math.round(v * 100)}%`} />
          <YAxis type="category" dataKey="feature" tick={{ fontSize: 11 }} width={90} />
          <Tooltip formatter={(v) => `${(Number(v) * 100).toFixed(1)}%`} />
          <Bar dataKey="importance" fill="#f4791f" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
