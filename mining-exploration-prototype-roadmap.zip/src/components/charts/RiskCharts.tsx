"use client";

import { Bar, BarChart, CartesianGrid, Cell, PolarAngleAxis, RadialBar, RadialBarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function RiskGauge({ score, color }: { score: number; color: string }) {
  return (
    <div className="h-48 relative">
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart innerRadius="70%" outerRadius="100%" data={[{ value: score }]} startAngle={210} endAngle={-30}>
          <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
          <RadialBar dataKey="value" cornerRadius={8} fill={color} background={{ fill: "#e2e8f0" }} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 grid place-items-center pointer-events-none">
        <div className="text-center mt-4">
          <div className="text-4xl font-black" style={{ color }}>
            {score}
          </div>
          <div className="text-xs text-slate-500">/ 100</div>
        </div>
      </div>
    </div>
  );
}

export function RiskComponentBars({ data }: { data: { name: string; contribution: number; max: number }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis type="number" tick={{ fontSize: 11 }} domain={[0, 40]} />
          <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={120} />
          <Tooltip formatter={(v, n) => [`${v} pts`, n === "max" ? "Max weight" : "Contribution"]} />
          <Bar dataKey="max" name="max" fill="#e2e8f0" radius={[0, 4, 4, 0]} barSize={14} />
          <Bar dataKey="contribution" name="contribution" radius={[0, 4, 4, 0]} barSize={14}>
            {data.map((d) => (
              <Cell key={d.name} fill={d.contribution / d.max > 0.66 ? "#dc2626" : d.contribution / d.max > 0.33 ? "#f59e0b" : "#16a34a"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
