"use client";

import { CartesianGrid, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function TodayChart({ points }: { points: { label: string; target: number; actual: number | null; predicted: number | null }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={points} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={1} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
          <Tooltip formatter={(v) => `${Number(v).toLocaleString()} T`} />
          <Legend />
          <Line type="monotone" dataKey="target" name="Target" stroke="#64748b" strokeDasharray="6 4" dot={false} isAnimationActive animationDuration={1200} />
          <Line type="monotone" dataKey="actual" name="Actual" stroke="#0b1526" strokeWidth={2.5} dot={{ r: 2 }} isAnimationActive animationDuration={1400} />
          <Line type="monotone" dataKey="predicted" name="Predicted" stroke="#f4791f" strokeWidth={2.5} strokeDasharray="4 2" dot={{ r: 2 }} isAnimationActive animationDuration={1800} />
          <ReferenceLine x="14:00" stroke="#f4791f" label={{ value: "now", fontSize: 10, fill: "#f4791f", position: "top" }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
