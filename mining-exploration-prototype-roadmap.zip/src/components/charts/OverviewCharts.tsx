"use client";

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function OverviewCharts({ data }: { data: { name: string; forecast: number; target: number; risk: number }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} barGap={6}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="name" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} unit=" MT" />
          <Tooltip />
          <Legend />
          <Bar dataKey="target" name="Target (MT)" fill="#94a3b8" radius={[4, 4, 0, 0]} />
          <Bar dataKey="forecast" name="Forecast (MT)" fill="#f4791f" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
