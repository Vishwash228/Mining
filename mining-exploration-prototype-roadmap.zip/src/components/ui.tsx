import type { ReactNode } from "react";
import type { RiskLevel } from "@/lib/ml";

export function Card({ children, className = "", title, subtitle, action }: { children: ReactNode; className?: string; title?: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className={`bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm ${className}`}>
      {(title || action) && (
        <div className="flex items-start justify-between px-5 pt-4 pb-2">
          <div>
            {title && <h3 className="font-semibold text-slate-800">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      <div className="px-5 pb-5 pt-2">{children}</div>
    </div>
  );
}

export function Kpi({ label, value, unit, hint, tone = "default" }: { label: string; value: string | number; unit?: string; hint?: string; tone?: "default" | "good" | "warn" | "bad" | "brand" }) {
  const tones = {
    default: "text-slate-900",
    good: "text-emerald-600",
    warn: "text-amber-600",
    bad: "text-red-600",
    brand: "text-orange-600",
  };
  return (
    <div className="vc-card-hover bg-white text-slate-900 rounded-xl border border-slate-200 shadow-sm p-5">
      <div className="text-xs uppercase tracking-wide text-slate-500 font-medium">{label}</div>
      <div className={`mt-2 text-3xl font-bold ${tones[tone]}`}>
        {value}
        {unit && <span className="text-base font-semibold text-slate-400 ml-1">{unit}</span>}
      </div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </div>
  );
}

export const potentialColor: Record<string, string> = {
  High: "#16a34a",
  Medium: "#f59e0b",
  Low: "#dc2626",
};

export function PotentialBadge({ level }: { level: string }) {
  const map: Record<string, string> = {
    High: "bg-emerald-100 text-emerald-800 border-emerald-200",
    Medium: "bg-amber-100 text-amber-800 border-amber-200",
    Low: "bg-red-100 text-red-800 border-red-200",
  };
  return <span className={`inline-block text-xs font-semibold px-2 py-0.5 rounded-full border ${map[level] ?? ""}`}>{level}</span>;
}

export function RiskBadge({ level }: { level: RiskLevel }) {
  const map: Record<RiskLevel, string> = {
    Low: "bg-emerald-100 text-emerald-800 border-emerald-200",
    Medium: "bg-amber-100 text-amber-800 border-amber-200",
    High: "bg-orange-100 text-orange-800 border-orange-200",
    Critical: "bg-red-100 text-red-800 border-red-200",
  };
  return <span className={`inline-block text-xs font-semibold px-2 py-0.5 rounded-full border ${map[level]}`}>{level}</span>;
}

export function riskColor(level: RiskLevel) {
  return { Low: "#16a34a", Medium: "#f59e0b", High: "#ea580c", Critical: "#dc2626" }[level];
}

export function PageHeader({ step, title, description, children }: { step: string; title: string; description: string; children?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div>
        <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">{step}</div>
        <h1 className="text-2xl font-bold text-white">{title}</h1>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl">{description}</p>
      </div>
      {children}
    </div>
  );
}

export function NextStep({ href, label }: { href: string; label: string }) {
  return (
    <a href={href} className="no-print inline-flex items-center gap-2 rounded-lg bg-amber-500 text-[#0b1526] px-4 py-2 text-sm font-semibold hover:bg-amber-400">
      {label} <span aria-hidden>→</span>
    </a>
  );
}

export function DemoBanner() {
  return (
    <div className="text-[11px] text-amber-200 bg-amber-500/10 border border-amber-400/30 rounded-md px-3 py-1.5 inline-flex items-center gap-2">
      <span className="h-2 w-2 rounded-full bg-amber-500" /> Prototype data — synthetic demo data. Not certified reserves.
    </div>
  );
}
