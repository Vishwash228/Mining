"use client";

import { usePathname } from "next/navigation";

export default function MineSwitcher({ mines, selectedId }: { mines: { id: number; name: string }[]; selectedId: number }) {
  const path = usePathname();
  return (
    <label className="flex items-center gap-2 text-xs text-slate-500">
      <span>Mine</span>
      <select
        className="rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm font-medium text-slate-800"
        value={selectedId}
        onChange={(e) => {
          window.location.href = `/api/select-mine?id=${e.target.value}&next=${encodeURIComponent(path)}`;
        }}
      >
        {mines.map((m) => (
          <option key={m.id} value={m.id}>
            {m.name}
          </option>
        ))}
      </select>
    </label>
  );
}
