"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

type Item = { href: string; label: string };
type Group = { label: string; icon: string; base: string; items: Item[] };

const GROUPS: Group[] = [
  {
    label: "Reserve Intelligence", icon: "◈", base: "/reserve",
    items: [
      { href: "/mines", label: "Overview" },
      { href: "/drillholes", label: "Drill Holes" },
      { href: "/drillholes#model", label: "Grade Model" },
      { href: "/map", label: "Kriging Map" },
      { href: "/module/reserve/3d-model", label: "3D Model" },
      { href: "/map", label: "Zone Analysis" },
      { href: "/module/reserve/resource-estimate", label: "Resource Estimate" },
    ],
  },
  {
    label: "Satellite Intelligence", icon: "🛰", base: "/satellite",
    items: [
      { href: "/satellite", label: "Overview" },
      { href: "/satellite#ndvi", label: "NDVI" },
      { href: "/module/satellite/ndwi", label: "NDWI" },
      { href: "/module/satellite/lst", label: "LST" },
      { href: "/module/satellite/rainfall", label: "Rainfall" },
      { href: "/module/satellite/soil-moisture", label: "Soil Moisture" },
      { href: "/module/satellite/terrain", label: "Terrain" },
      { href: "/module/satellite/change-detection", label: "Change Detection" },
    ],
  },
  {
    label: "Production Intelligence", icon: "↗", base: "/production",
    items: [
      { href: "/forecast", label: "Overview" },
      { href: "/forecast", label: "Forecast" },
      { href: "/risk", label: "Shortfall Prediction" },
      { href: "/module/production/factors", label: "Production Factors" },
      { href: "/forecast#history", label: "Historical Trends" },
      { href: "/module/production/what-if", label: "What-If Analysis" },
    ],
  },
  {
    label: "Equipment Intelligence", icon: "⚙", base: "/equipment",
    items: [
      { href: "/equipment", label: "Overview" },
      { href: "/equipment#live", label: "Live Monitoring" },
      { href: "/equipment#health", label: "Machine Health" },
      { href: "/equipment#anomaly", label: "Anomaly Detection" },
      { href: "/module/equipment/maintenance", label: "Maintenance" },
      { href: "/module/equipment/downtime", label: "Downtime" },
    ],
  },
];

const SINGLES: { href: string; label: string; icon: string }[] = [
  { href: "/recommendations", label: "Alerts & Actions", icon: "⚠" },
  { href: "/module/ai-model-center", label: "AI Model Center", icon: "✦" },
  { href: "/module/analytics", label: "Analytics", icon: "▤" },
  { href: "/reports", label: "Reports", icon: "▥" },
  { href: "/architecture", label: "Data Sources", icon: "⬡" },
  { href: "/module/data-upload", label: "Data Upload", icon: "⇪" },
  { href: "/module/settings", label: "Settings", icon: "⚙" },
];

export default function Sidebar() {
  const path = usePathname();
  const [open, setOpen] = useState<Record<string, boolean>>(() => {
    const o: Record<string, boolean> = {};
    for (const g of GROUPS) o[g.label] = g.items.some((i) => i.href.split("#")[0] === path);
    return o;
  });
  const isActive = (href: string) => href.split("#")[0] === path;

  return (
    <aside className="vc-sidebar no-print w-64 shrink-0 bg-[#0b1526] text-white min-h-screen flex flex-col border-r border-white/5 sticky top-0 max-h-screen">
      <div className="p-4 flex items-center gap-3 border-b border-white/10">
        <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 grid place-items-center font-black text-[#0b1526]">V</div>
        <div>
          <div className="font-black text-sm tracking-[0.2em] leading-tight">VISION CRAFT</div>
          <div className="text-[10px] text-slate-400">Mining Intelligence Platform</div>
        </div>
      </div>
      <nav className="p-3 space-y-0.5 overflow-y-auto flex-1 text-sm">
        <Link href="/dashboard" className={`flex items-center gap-3 px-3 py-2 rounded-lg transition ${path === "/dashboard" ? "bg-amber-500 text-[#0b1526] font-semibold" : "text-slate-300 hover:bg-white/10 hover:text-white"}`}>
          <span className="w-5 text-center">▦</span> Dashboard
        </Link>
        {GROUPS.map((g) => {
          const groupActive = g.items.some((i) => isActive(i.href));
          const expanded = open[g.label];
          return (
            <div key={g.label}>
              <button
                onClick={() => setOpen({ ...open, [g.label]: !expanded })}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition ${groupActive ? "text-amber-300" : "text-slate-300 hover:bg-white/10 hover:text-white"}`}
              >
                <span className="w-5 text-center">{g.icon}</span>
                <span className="flex-1 text-left font-medium">{g.label}</span>
                <span className={`text-[10px] transition-transform ${expanded ? "rotate-90" : ""}`}>▶</span>
              </button>
              <div className={`overflow-hidden transition-all duration-300 ${expanded ? "max-h-96" : "max-h-0"}`}>
                {g.items.map((i, idx) => (
                  <Link
                    key={g.label + idx}
                    href={i.href}
                    className={`flex items-center gap-2 pl-11 pr-3 py-1.5 text-[13px] rounded-lg transition ${isActive(i.href) && idx === g.items.findIndex((x) => isActive(x.href)) ? "text-amber-300 bg-white/5" : "text-slate-400 hover:text-white hover:bg-white/5"}`}
                  >
                    {i.label}
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
        <div className="pt-2 mt-2 border-t border-white/10 space-y-0.5">
          {SINGLES.map((s) => (
            <Link key={s.href} href={s.href} className={`flex items-center gap-3 px-3 py-2 rounded-lg transition ${path === s.href ? "bg-amber-500 text-[#0b1526] font-semibold" : "text-slate-300 hover:bg-white/10 hover:text-white"}`}>
              <span className="w-5 text-center">{s.icon}</span> {s.label}
            </Link>
          ))}
        </div>
      </nav>
      <div className="vc-online p-4 border-t border-white/10 flex items-center justify-between text-[11px]">
        <span className="flex items-center gap-2 text-emerald-300">
          <span className="h-2 w-2 rounded-full bg-emerald-400 vc-online-dot" /> System Online
        </span>
        <span className="text-slate-500">Version 1.0</span>
      </div>
    </aside>
  );
}
