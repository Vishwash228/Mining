import {
  pgTable,
  serial,
  text,
  real,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const mines = pgTable("mines", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // e.g. "MINE-B"
  name: text("name").notNull(),
  district: text("district").notNull(),
  state: text("state").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  mineType: text("mine_type").notNull(), // Opencast / Underground
  annualTargetMt: real("annual_target_mt").notNull(), // million tonnes
  predictedReserveMt: real("predicted_reserve_mt").notNull(),
  avgGradeMnPct: real("avg_grade_mn_pct").notNull(),
  activeSince: integer("active_since").notNull(),
});

export const zones = pgTable("zones", {
  id: serial("id").primaryKey(),
  mineId: integer("mine_id").notNull(),
  code: text("code").notNull(), // e.g. "B3"
  name: text("name").notNull(),
  potential: text("potential").notNull(), // High / Medium / Low
  probability: real("probability").notNull(), // 0-1 manganese probability
  estReserveMt: real("est_reserve_mt").notNull(),
  avgGradeMnPct: real("avg_grade_mn_pct").notNull(),
  areaHa: real("area_ha").notNull(),
  ndvi: real("ndvi").notNull(),
  ironOxideIndex: real("iron_oxide_index").notNull(),
  clayIndex: real("clay_index").notNull(),
  polygon: text("polygon").notNull(), // JSON [[lat,lng],...]
  notes: text("notes"),
});

export const drillholes = pgTable("drillholes", {
  id: serial("id").primaryKey(),
  mineId: integer("mine_id").notNull(),
  zoneId: integer("zone_id"),
  holeId: text("hole_id").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  depthM: real("depth_m").notNull(),
  mnPct: real("mn_pct").notNull(),
  fePct: real("fe_pct").notNull(),
  sio2Pct: real("sio2_pct").notNull(),
  thicknessM: real("thickness_m").notNull(),
  rockType: text("rock_type").notNull(),
  drilledYear: integer("drilled_year").notNull(),
});

export const production = pgTable("production", {
  id: serial("id").primaryKey(),
  mineId: integer("mine_id").notNull(),
  year: integer("year").notNull(),
  month: integer("month").notNull(),
  producedKt: real("produced_kt").notNull(), // thousand tonnes
  targetKt: real("target_kt").notNull(),
  gradeMnPct: real("grade_mn_pct").notNull(),
  equipmentUptimePct: real("equipment_uptime_pct").notNull(),
  rainfallMm: real("rainfall_mm").notNull(),
  isForecast: boolean("is_forecast").notNull().default(false),
});

export const satelliteFeatures = pgTable("satellite_features", {
  id: serial("id").primaryKey(),
  mineId: integer("mine_id").notNull(),
  captureDate: text("capture_date").notNull(),
  sensor: text("sensor").notNull(), // Sentinel-2 / Landsat-8
  ndvi: real("ndvi").notNull(),
  ironOxideIndex: real("iron_oxide_index").notNull(),
  clayIndex: real("clay_index").notNull(),
  bareSoilIndex: real("bare_soil_index").notNull(),
  landSurfaceTempC: real("land_surface_temp_c").notNull(),
  cloudCoverPct: real("cloud_cover_pct").notNull(),
});

export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  mineId: integer("mine_id").notNull(),
  code: text("code").notNull(), // E04
  name: text("name").notNull(),
  type: text("type").notNull(), // Excavator / Dumper / Drill / Loader / Crusher
  status: text("status").notNull(), // Healthy / Warning / Critical / Maintenance
  healthScore: real("health_score").notNull(),
  vibrationMmS: real("vibration_mm_s").notNull(),
  temperatureC: real("temperature_c").notNull(),
  runtimeHours: real("runtime_hours").notNull(),
  lastServiceDays: integer("last_service_days").notNull(),
  note: text("note"),
});

export type Equipment = typeof equipment.$inferSelect;

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  username: text("username").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Mine = typeof mines.$inferSelect;
export type Zone = typeof zones.$inferSelect;
export type Drillhole = typeof drillholes.$inferSelect;
export type Production = typeof production.$inferSelect;
export type SatelliteFeature = typeof satelliteFeatures.$inferSelect;
