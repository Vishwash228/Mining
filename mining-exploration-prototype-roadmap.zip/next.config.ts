import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Produces .next/standalone for the Docker image (Vercel ignores this)
  output: "standalone",
};

export default nextConfig;
